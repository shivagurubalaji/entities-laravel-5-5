<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php wp_title();?></title>
	

<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php wp_head();?>
	<meta property="og:image" content="https://www.fpmarketsinternational.com/wp-content/themes/FPMarkets/images/default-header.jpg" />
    
    <!-- fav -->
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="/apple-touch-icon-114x114.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="/apple-touch-icon-144x144.png" />
    <link rel="apple-touch-icon-precomposed" sizes="60x60" href="/apple-touch-icon-60x60.png" />
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="/apple-touch-icon-120x120.png" />
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="/apple-touch-icon-76x76.png" />
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="/apple-touch-icon-152x152.png" />
    <link rel="icon" type="image/png" href="/favicon-196x196.png" sizes="196x196" />
    <link rel="icon" type="image/png" href="/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="/favicon-128.png" sizes="128x128" />
    <meta name="application-name" content="fpmarketsinternational.com"/>
    <meta name="msapplication-TileColor" content="#FFFFFF" />
    <meta name="msapplication-TileImage" content="/mstile-144x144.png" />
    <meta name="msapplication-square70x70logo" content="/mstile-70x70.png" />
    <meta name="msapplication-square150x150logo" content="/mstile-150x150.png" />
    <meta name="msapplication-wide310x150logo" content="/mstile-310x150.png" />
    <meta name="msapplication-square310x310logo" content="/mstile-310x310.png" />
    <link href="/wp-content/themes/FPMarkets/assets/css/bootstrap-nc-min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/wp-content/themes/FPMarkets/assets/css/style.css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:200,300,400,600,700&display=swap" rel="stylesheet">

	<script src="/wp-content/themes/FPMarkets/assets/jquery.min.js"></script>


    
    <link rel="stylesheet" href="https://fpmarketsinternational.com/wp-content/themes/FPMarkets/stylesdec.css?v=1.01" type="text/css" /> 

	
	<style>
    .menu li {
    font-size: 16px!important;
    line-height: 26px!important;
    font-weight: 300!important;
    color: #ffffff!important;
}
.header-btns {
    font-weight: 600;
    color: #ffffff;
    font-size: 14px;
    text-align: center;
    border-radius: 0px 10px 10px 10px!important;
    border: 1px solid rgb(255 255 255 / 0.3);
    padding: 2px;
}
        
 
.social_menu_icon:after {
    content: "";
    display: block;
    position: absolute;
    right: 0px;
    margin-top: -22px;
    vertical-align: middle;
    width: 35px;
    height: 20px;
    background: url(/wp-content/themes/FPMarkets/images/menu_new_icon.png) left top no-repeat;
    padding-right: 50px;
}
        
.social_menu_icon2:after {
    content: "";
    display: block;
    position: absolute;
    right: 0px;
    margin-top: -22px;
    vertical-align: middle;
    width: 35px;
    height: 20px;
    background: url(/wp-content/themes/FPMarkets/images/menu_new_icon.png) left top no-repeat;
    padding-right: 180px;
}
        
.header-btns2 {
    font-weight: 600;
    color: #ffffff;
    font-size: 14px;
    text-align: center;
    border-radius: 0px 10px 10px 10px;
    border: 1px solid rgb(255 255 255 / 0.3);
    padding: 2px;
    background:#1b2a51;
}
.headers .header-btns2:hover {
	background: #00beff;
    color: #ffffff;
}
.app_menu_icon:after {
    content: "";
    display: block;
    position: absolute;
    right: 0px;
    margin-top: -22px;
    vertical-align: middle;
    width: 35px;
    height: 20px;
    background: url(/wp-content/themes/FPMarkets/images/menu_new_icon.png) left top no-repeat;
    padding-right: 40px;
}
        
.pro_menu_icon:after {
    content: "";
    display: block;
    position: absolute;
    right: 0px;
    margin-top: -22px;
    vertical-align: middle;
    width: 35px;
    height: 20px;
    background: url(/wp-content/themes/FPMarkets/images/menu_new_icon.png) left top no-repeat;
    padding-right: 100px;
}
        
.app_menu_icon2:after {
    content: "";
    display: block;
    position: absolute;
    right: 0px;
    margin-top: -15px;
    vertical-align: middle;
    width: 35px;
    height: 20px;
    background: url(/wp-content/themes/FPMarkets/images/menu_new_icon30.png) left top no-repeat;
    padding-right: 40px;
}
        
.pro_menu_icon2:after {
    content: "";
    display: block;
    position: absolute;
    left: 110px;
    margin-top: -15px;
    vertical-align: middle;
    width: 30px;
    height: 17px;
    background: url(/wp-content/themes/FPMarkets/images/menu_new_icon30.png) left top no-repeat;
    
}
        
@media (max-width: 767px) {
    
     .social_menu_icon:after {
        left: 240px;
    }
    .social_menu_icon2:after {
        left: 240px;
    }
    .app_menu_icon:after {
        left: 200px;
        margin-top: -30px;
    }
    .app_menu_icon2:after {
        left: 240px;
        margin-top: -22px;
    }
    .pro_menu_icon:after {
        left: 220px;
        margin-top: -28px;
    }
    .pro_menu_icon2:after {
        left: 264px;
        margin-top: -20px;
    }
}

        .dropdown-menu .container {
            padding-left: 24px;
        }
        .dropdown-menu li ul {
            padding-bottom: 10px;
        }
    
        .trp-language-switcher {
            z-index:99999999;
        }
@font-face {
  font-display: swap;
}
.trp-language-switcher > div {
	box-sizing: border-box;
    padding: 0px;
    border:1px solid rgba(238, 238, 238, .1);
	border-radius:0px;
    background:none;
	z-index:999999;
	text-align:left;
}
.code-block {
	margin:3px!important;
}
.trp-language-switcher > div > a {
	color:#ffffff;
}
.trp-ls-shortcode-language:hover {
	background:#272c37;
	z-index:999999;
}

.trp-language-switcher > div > a:hover {
    background: #272c37;
	z-index:999999;
}
</style>
    
</head>

<body <?php body_class();?>>
<?php 

remove_filter ('the_content', 'wpautop'); 

 ?>
<style>
 <style type="text/css">
        *,
        *:before,
        *:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0;margin:0;}
        h2,
        h3{font-weight:bold;color:#2d2f39;text-align:center;}
        img{max-width:100%;}
        .inner{max-width:1175px;margin:0 auto;padding:0px 20px;width:100%;}
        .mt4 .banner{background:url("./mt4-fpm/banner_back.jpg") center center no-repeat;background-size:cover;height:800px;position:relative;overflow:hidden;}
        .mt4 .banner .banner_right h3{font-size:44px;line-height:1;margin-bottom:20px;font-weight:normal;color:#fff;}
        .banner_small{display:none;}
        .btn_down{cursor:pointer;}

        /* banner form */
    .fp-demo-signup-global input[type=submit], .element .gform_wrapper .gform_button {
        width: 90%;
    }
        .gform_success{padding:20px;display:none;color:#fff;font-size: 16px;}
        .fourth{padding-left:30px;position:absolute;top:50px;left:55%;text-align:center;width:380px;}
        .fourth h3{font-size:44px;line-height:1;margin-bottom:20px;font-weight:lighter;margin-top:0;color:#ffff;}
        .fourth h3 span{font-size:40px;color:orange;}
        .cui_freeimg{width:100%;height:100%;overflow:hidden;}
        .cui_freeimg img{width:100%;}
        .cui_free_right{margin-top:35%;}
        .fourth input{width:90%;border:1px solid orange;height:45px;display:inline;outline:none;}
        .form-control{padding:6px 12px;font-size:14px;line-height:1.42857143;color:#555;background-color:#fff;background-image:none;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;-o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;width:100%;}
        .fourth .verification{width:35%;}
        .fourth a{width:30%;height:45px;padding:10px 12px;background:orange;color:#fff;font-size:18px;margin-top:-4px;}
        .fourth button{width:65%;background:orange;color:#fff;padding:10px 12px;font-size:20px;outline:none;border:none;cursor:pointer;}
        .fourth .radio input{width:20px;height:15px;display:none;}
        .radfu{position:relative;}
        .fourth .radio{position:absolute;bottom:0;right:20%;}
        .demo--radioInput{background-color:#fff;border:2px solid rgba(0,0,0,0.15);border-radius:100%;display:inline-block;height:20px;margin-right:5px;margin-top:-1px;vertical-align:middle;width:21px;line-height:1;}
        .demo--checkbox.demo--radioInput,
        .demo--radio:checked + .demo--checkbox.demo--radioInput:after{border-radius:0;}
        .demo--radio:checked + .demo--radioInput{border:2px solid rgba(0,0,0,0.15);}
        .row{margin-left:0!important;margin-right:0!important;}
        .form-control:focus {
            border-color: #66afe9;
            outline: 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
        }
        /* 模态框 */
        .modal-body{padding:10px;}
        .modal-header{padding:15px;border-bottom:1px solid #e5e5e5;}
        .close{display: inline-block;float:right;margin-top: -5px;}
        .close span{font-size:21px;font-weight:700;line-height:1;color:#ccc;text-shadow:0 1px 0 #fff;margin:0px 10px 0px 0px;cursor:pointer;}
        .modal-content{position:relative;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #999;border:1px solid rgba(0,0,0,.2);border-radius:6px;outline:0;-webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);box-shadow:0 3px 9px rgba(0,0,0,.5);width:600px;margin:30px auto;}
        #myModal{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1050;display:none;width:100%;}
        #myModal h3{font-size:44px;line-height:1;font-weight:lighter;}
        #myModal h3 span{font-size:40px;color:orange;}
        #myModal .gform_success{color: #2d2f39;text-align:center;}
        .modal input{border:1px solid orange;height:45px;outline:none;}
        .modal .btnn{background:orange;width:100%;height:45px;color:#fff;font-size:18px;padding:10px 12px;outline:none;border:none;cursor:pointer;}
        .modal .verification{display:inline;width:65%;box-sizing:border-box;}
        .modal .btna{width:32%;background:orange;height:45px;color:#fff;font-size:18px;padding:10px 10px;margin-top:-6px;margin-left:5px;box-sizing:border-box;}
        #myModal .demo--radioInput{background-color:#fff;border:2px solid rgba(0,0,0,0.15);border-radius:100%;display:inline-block;height:20px;margin-right:5px;margin-top:-1px;vertical-align:middle;width:21px;line-height:1;}
        #myModal .demo--radio:checked + .demo--radioInput:after{background-color:orange;border-radius:100%;content:"";display:inline-block;height:14px;margin-left:0;margin-top:1px;width:13px;}
        #myModal .demo--checkbox.demo--radioInput,
        .demo--radio:checked + .demo--checkbox.demo--radioInput:after{border-radius:0;}
        #myModal .demo--radio:checked + .demo--radioInput{border:2px solid rgba(0,0,0,0.15);}
        #myModal .radio{position:absolute;right:5px;top:0;}
        #myModal .radio input[type=radio]{margin:0;top:-10px;left:25px;z-index:-100;}
        .form-group{margin-bottom:30px;}
        .radio_box{position:absolute;width:auto;top:0;right:20%;padding:13px 0;}
        .radio_box input[type="radio"]{display:inline-block;height:20px;width:30px;vertical-align:middle;margin:0;cursor:pointer;}
        .modal-dialog .radio_box{right:3%;}
        .modal-backdrop{opacity:.5;position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000;display:none;cursor:pointer;}
        .mt4 .mt4_content{padding-top:89px;}
        .mt4 h2.title{font-size:45px;position:relative;margin-bottom:119px;}
        .mt4 h2.title:before{content:"";position:absolute;background:url("./mt4-fpm/title_left.png");width:87px;height:93px;left:16%;top:-30%;background-size:100% 100%;}
        .mt4 h2.title:after{content:"";position:absolute;background:url("./mt4-fpm/title_right.png");width:56px;height:78px;right:18%;top:-15%;background-size:100% 100%;}

        /* 小尺寸  mt4_advantage*/
        .box_small{display:none;}
        .mt4 .mt4_content .box_small .btn_down{margin:0 auto;max-width:520px;height:88px;line-height:88px;font-size:34px;color:#fff;text-align:center;background-image:linear-gradient(270deg,#1052f7 17%,#2cc4fe 83%);border-radius:50px;}
        .mt4 .mt4_content .box_small img{max-width:116px;}
        .box_small .mt4_advantage ul li{display:inline-block;width:46%;}
        .box_small .mt4_advantage ul li h3{font-size:30px;color:#666;font-weight:normal;}
        .box_small .mt4_advantage ul li p{color:#999;}
        .mt4 .box_small h2.title:before{left:16%;}
        .mt4 .box_small h2.title:after{right:18%;}

        /* 大尺寸  mt4_advantage*/
        .mt4_advantage{margin-bottom:92px;}
        .mt4_advantage ul{font-size:0;margin-right:-2%;margin-left:-2%;text-align:center;}
        .mt4_advantage ul li{display:inline-block;width:21%;margin-right:2%;margin-left:2%;vertical-align:top;}
        .mt4_advantage ul li>img{margin-bottom:30px;}
        .mt4_advantage ul li h3{text-align:center;margin-bottom:20px;font-size:34px;}
        .mt4_advantage ul li p{font-size:21px;color:#738086;margin-bottom:92px;}
        .mt4_advantage ul li div{background-color:#00d577;font-size:22px;width:100%;color:#fff;height:58px;line-height:58px;text-align:center;}
        .mt4_advantage ul li div img{vertical-align:middle;}
        .mt4_major{font-size:0;}
        .mt4_active{background:url("./mt4-fpm/mt4_active.jpg") bottom center no-repeat;background-size:cover;height:240px;overflow:hidden;margin-bottom:92px;}
        .mt4_active p{font-size:48px;color:#fff;padding-top:60px;}
        .mt4_active .btn_down{background-image:linear-gradient(100deg,#fb515e,#fb694f),linear-gradient(#fff,#fff);border-radius:5px;font-size:20px;text-align:center;height:58px;line-height:58px;width:192px;float:right;color:#fff;margin-top:-20px;}
        .mt4 .mt4_down h2.title:before{left:30%;}
        .mt4 .mt4_down h2.title:after{right:34%;}
        .mt4_down{margin-bottom:104px;}
        .mt4_down ul{font-size:0;margin-left:-3%;margin-right:-3%;text-align:center;}
        .mt4_down ul li{margin-left:3%;margin-right:3%;width:19%;display:inline-block;vertical-align:top;border:1px solid #e7ecef;font-size:18px;color:#555;padding:30px 5px;text-align:center;border-radius:5px;}
        .mt4_down ul li img{vertical-align:middle;margin-right:15px;}

        /* 小尺寸 */
        .mt4_down .mt4_down_small{display:none;}
        .mt4_down .mt4_down_small ul li{width:36%;border:1px solid #979797;padding:50px 10px 30px;margin:0px 3%;}
        .mt4_down .mt4_down_small ul li div{min-height:120px;margin-bottom:40px;}
        .mt4_down .mt4_down_small ul li div img{margin:0;}
        .mt4_down .mt4_down_small ul li p{font-size:24px;color:#333;}
        .footer{text-align:center;background:#292b33;padding:50px 0px;}
        .footer p{line-height:1.8;color:#a6a6a6;font-size:16px;}
        .hide_form{display: none;}
        @media (max-width:1220px){
            .mt4_down ul,.mt4_advantage ul{margin-left:0;margin-right: 0;}
        }
        @media (max-width:1180px){
            .mt4 h2.title:before{left:12%;}
            .mt4 h2.title:after{right:14%;}
        }
        @media (max-width:1160px){
            .mt4_advantage ul li>img{width:80%;}
            .mt4_advantage ul li p{font-size:18px;}
            .mt4_advantage ul li h3{font-size:30px;}
            .mt4_advantage ul{margin-right:-1%;margin-left:-1%;}
            .mt4_advantage ul li{display:inline-block;width:23%;margin-right:1%;margin-left:1%;vertical-align:top;}
            .mt4_advantage ul li div{font-size:18px;}
        }
        @media (max-width:1120px){
            .mt4 .banner{height:600px;}
            .cui_free_right{margin-top:25%;}
            .fourth{left:45%;}

        }
        @media (max-width:1180px){
            .mt4 h2.title:before{left:10%;}
            .mt4 h2.title:after{right:12%;}
        }
        @media (max-width:1050px){
            .mt4_active{height:200px;}
            .mt4 .mt4_down h2.title:before{left:26%;}
            .mt4 .mt4_down h2.title:after{right:28%;}
            .mt4_down ul li{margin-left:1%;margin-right:1%;width:23%;}
            .mt4_down ul{margin-left:0;margin-right:0;}
        }
        @media (max-width:992px){
            .fourth{left:45%;width:520px;}
            #myModal h3,
            #myModal h3 span,
            .fourth h3,
            .fourth h3 span{font-size:38px;}
            .mt4 h2.title:before{left:8%;}
            .mt4 h2.title:after{right:10%;}
        }
        @media (max-width:930px){
            .mt4 h2.title:before{left:4%;}
            .mt4 h2.title:after{right:6%;}
            .mt4_advantage ul li p{font-size:16px;}
            .mt4_active{height:150px;}
            .mt4_active .btn_down{margin-top:-35px;}
            .mt4_active p{padding-top:50px;font-size:38px;}
            .mt4_down ul li{font-size:16px;}
        }
        @media (max-width:840px){
            .cui_free_right{margin-top:40px;}
            .banner_small{display:block;}
            .mt4 .banner{background:none;height:auto;}
            .fourth{padding-left:0px;position:initial;margin:0 auto;width:100%;}
            .cui_free_right h3{color:#2d2f39;}
            .fourth .form_text{color:#2d2f39!important;padding:0px 20px;}
            .box_big{display:none;}
            .box_small{display:block;}
            .mt4_major{display:none;}
            .mt4_active .btn_down{margin-top:0px;float:none;}
            .mt4_active{background:url("./mt4-fpm/mt4_active_small.jpg?v=1") bottom right no-repeat;height:257px;background-size:cover;margin-bottom:50px;}
            .mt4_active p{margin-bottom:26px;}
            .mt4_down .mt4_down_big{display:none;}
            .mt4_down .mt4_down_small{display:block;}
            .mt4_down{margin-bottom:50px;}
            .footer{background:#f1f5fb;padding:10px 0px;}
            .banner .gform_success{color:#2d2f39;}
        }
        @media (max-width:740px){
            .mt4 .box_small h2.title:before{left:12%;}
            .mt4 .box_small h2.title:after{right:16%;}
            .mt4_down .mt4_down_small ul li{width:44%;}
        }
        @media (max-width:650px){
            .mt4 .box_small h2.title:before{width:61px;height:65px;top:-40%;}
            .mt4 .box_small h2.title:after{width:39px;height:55px;top:-40%;}
            .box_small .mt4_advantage ul li p{margin-bottom:30px;}
            .mt4 .mt4_content .box_small .btn_down{height:50px;line-height:50px;font-size:24px;}
            .mt4 h2.title{margin-bottom:60px;font-size:30px;}
            .mt4_advantage ul{margin:0px 0px 40px;}
            .box_small .mt4_advantage ul li h3{font-size:24px;}
            .mt4_active{height:200px;background-size:cover;}
            .mt4_active p{font-size:30px;}
            .mt4_active .btn_down{font-size:18px;height:48px;line-height:48px;}
            .mt4_down .mt4_down_small ul li p{font-size:18px;}
            .mt4_down .mt4_down_small ul li{padding:30px 10px;}
            .mt4_down .mt4_down_small ul li div{margin-bottom:20px;}
            .modal-content{width:90%;}
        }
        @media (max-width:500px){
            .fourth input,
            .fourth button{width:90%;}
            .radio_box{right:10%;}
             #myModal h3,
            #myModal h3 span,
            .fourth h3,
            .fourth h3 span{font-size:30px;}
            .mt4 .box_small h2.title:before{left:4%;}
            .mt4 .box_small h2.title:after{right:8%;}
            .mt4_active{height:160px;}
            .mt4_active p{padding-top:28px;font-size:24px;}
            .mt4_active .btn_down{font-size:16px;height:40px;line-height:40px;}
        }
        @media (max-width:450px){
            .mt4_down .mt4_down_small ul li{width:80%;margin:0 auto;margin-bottom:30px;}
        }
        @media (max-width:400px){
            .mt4 .box_small h2.title:before{left:0%;}
            .mt4 .box_small h2.title:after{right:0%;}
            .mt4_active{background-position:left;}
            #myModal h3, #myModal h3 span, .fourth h3, .fourth h3 span {
                font-size: 26px;
            }
        }
        @media (max-width:350px){
            .mt4 .box_small h2.title:before{width:43px;height:46px;top:-20%;}
            .mt4 .box_small h2.title:after{width:27px;height:38px;top:-20%;}
        }

    </style>

</style>



<body class="home page-template page-template-template-home page-template-template-home-php page page-id-5" data-new-gr-c-s-check-loaded="14.997.0" data-gr-ext-installed="">
    <style type="text/css">
        *,
        *:before,
        *:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:0;margin:0;}
        h2,
        h3{font-weight:bold;color:#2d2f39;text-align:center;}
        img{max-width:100%;}
        .inner{max-width:1175px;margin:0 auto;padding:0px 20px;width:100%;}
        .mt4 .banner{background:url("/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/banner_back-2.jpg") center center no-repeat;background-size:cover;height:800px;position:relative;overflow:hidden;}
        .mt4 .banner .banner_right h3{font-size:44px;line-height:1;margin-bottom:20px;font-weight:normal;color:#fff;}
        .banner_small{display:none;}
        .btn_down{cursor:pointer;}

        /* banner form */
        .gform_success{padding:20px;display:none;color:#fff;font-size: 16px;}
        .fourth{padding-left:30px;position:absolute;top:50px;left:55%;text-align:center;width:380px;}
        .fourth h3{font-size:44px;line-height:1;margin-bottom:20px;font-weight:lighter;margin-top:0;color:#ffff;}
        .fourth h3 span{font-size:40px;color:orange;}
        .cui_freeimg{width:100%;height:100%;overflow:hidden;}
        .cui_freeimg img{width:100%;}
        .cui_free_right{margin-top:35%;}
        .fourth input{width:90%;border:1px solid orange;height:45px;display:inline;outline:none;}
        .form-control{padding:6px 12px;font-size:14px;line-height:1.42857143;color:#555;background-color:#fff;background-image:none;border-radius:4px;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.075);box-shadow:inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition:border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;-o-transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s;width:100%;}
        .fourth .verification{width:35%;}
        .fourth a{width:30%;height:45px;padding:10px 12px;background:orange;color:#fff;font-size:18px;margin-top:-4px;}
        .fourth button{width:65%;background:orange;color:#fff;padding:10px 12px;font-size:20px;outline:none;border:none;cursor:pointer;}
        .fourth .radio input{width:20px;height:15px;display:none;}
        .radfu{position:relative;}
        .fourth .radio{position:absolute;bottom:0;right:20%;}
        .demo--radioInput{background-color:#fff;border:2px solid rgba(0,0,0,0.15);border-radius:100%;display:inline-block;height:20px;margin-right:5px;margin-top:-1px;vertical-align:middle;width:21px;line-height:1;}
        .demo--checkbox.demo--radioInput,
        .demo--radio:checked + .demo--checkbox.demo--radioInput:after{border-radius:0;}
        .demo--radio:checked + .demo--radioInput{border:2px solid rgba(0,0,0,0.15);}
        .row{margin-left:0!important;margin-right:0!important;}
        .form-control:focus {
            border-color: #66afe9;
            outline: 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102,175,233,.6);
        }
        /* 模态框 */
        .modal-body{padding:10px;}
        .modal-header{padding:15px;border-bottom:1px solid #e5e5e5;}
        .close{display: inline-block;float:right;margin-top: -5px;}
        .close span{font-size:21px;font-weight:700;line-height:1;color:#ccc;text-shadow:0 1px 0 #fff;margin:0px 10px 0px 0px;cursor:pointer;}
        .modal-content{position:relative;background-color:#fff;-webkit-background-clip:padding-box;background-clip:padding-box;border:1px solid #999;border:1px solid rgba(0,0,0,.2);border-radius:6px;outline:0;-webkit-box-shadow:0 3px 9px rgba(0,0,0,.5);box-shadow:0 3px 9px rgba(0,0,0,.5);width:600px;margin:30px auto;}
        #myModal{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:1050;display:none;width:100%;}
        #myModal h3{font-size:44px;line-height:1;font-weight:lighter;}
        #myModal h3 span{font-size:40px;color:orange;}
        #myModal .gform_success{color: #2d2f39;text-align:center;}
        .modal input{border:1px solid orange;height:45px;outline:none;}
        .modal .btnn{background:orange;width:100%;height:45px;color:#fff;font-size:18px;padding:10px 12px;outline:none;border:none;cursor:pointer;}
        .modal .verification{display:inline;width:65%;box-sizing:border-box;}
        .modal .btna{width:32%;background:orange;height:45px;color:#fff;font-size:18px;padding:10px 10px;margin-top:-6px;margin-left:5px;box-sizing:border-box;}
        #myModal .demo--radioInput{background-color:#fff;border:2px solid rgba(0,0,0,0.15);border-radius:100%;display:inline-block;height:20px;margin-right:5px;margin-top:-1px;vertical-align:middle;width:21px;line-height:1;}
        #myModal .demo--radio:checked + .demo--radioInput:after{background-color:orange;border-radius:100%;content:"";display:inline-block;height:14px;margin-left:0;margin-top:1px;width:13px;}
        #myModal .demo--checkbox.demo--radioInput,
        .demo--radio:checked + .demo--checkbox.demo--radioInput:after{border-radius:0;}
        #myModal .demo--radio:checked + .demo--radioInput{border:2px solid rgba(0,0,0,0.15);}
        #myModal .radio{position:absolute;right:5px;top:0;}
        #myModal .radio input[type=radio]{margin:0;top:-10px;left:25px;z-index:-100;}
        .form-group{margin-bottom:30px;}
        .radio_box{position:absolute;width:auto;top:0;right:20%;padding:13px 0;}
        .radio_box input[type="radio"]{display:inline-block;height:20px;width:30px;vertical-align:middle;margin:0;cursor:pointer;}
        .modal-dialog .radio_box{right:3%;}
        .modal-backdrop{opacity:.5;position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;background-color:#000;display:none;cursor:pointer;}
        .mt4 .mt4_content{padding-top:89px;}
        .mt4 h2.title{font-size:45px;position:relative;margin-bottom:119px;}
        .mt4 h2.title:before{content:"";position:absolute;background:url("/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/title_left.png");width:87px;height:93px;left:16%;top:-30%;background-size:100% 100%;}
        .mt4 h2.title:after{content:"";position:absolute;background:url("/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/title_right.png");width:56px;height:78px;right:18%;top:-15%;background-size:100% 100%;}

        /* 小尺寸  mt4_advantage*/
        .box_small{display:none;}
        .mt4 .mt4_content .box_small .btn_down{margin:0 auto;max-width:520px;height:88px;line-height:88px;font-size:34px;color:#fff;text-align:center;background-image:linear-gradient(270deg,#1052f7 17%,#2cc4fe 83%);border-radius:50px;}
        .mt4 .mt4_content .box_small img{max-width:116px;}
        .box_small .mt4_advantage ul li{display:inline-block;width:46%;}
        .box_small .mt4_advantage ul li h3{font-size:30px;color:#666;font-weight:normal;}
        .box_small .mt4_advantage ul li p{color:#999;}
        .mt4 .box_small h2.title:before{left:16%;}
        .mt4 .box_small h2.title:after{right:18%;}

        /* 大尺寸  mt4_advantage*/
        .mt4_advantage{margin-bottom:92px;}
        .mt4_advantage ul{font-size:0;margin-right:-2%;margin-left:-2%;text-align:center;}
        .mt4_advantage ul li{display:inline-block;width:21%;margin-right:2%;margin-left:2%;vertical-align:top;}
        .mt4_advantage ul li>img{margin-bottom:30px;}
        .mt4_advantage ul li h3{text-align:center;margin-bottom:20px;font-size:34px;}
        .mt4_advantage ul li p{font-size:21px;color:#738086;margin-bottom:92px;}
        .mt4_advantage ul li div{background-color:#00d577;font-size:22px;width:100%;color:#fff;height:58px;line-height:58px;text-align:center;}
        .mt4_advantage ul li div img{vertical-align:middle;}
        .mt4_major{font-size:0;}
        .mt4_active{background:url("/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_active.jpg") bottom center no-repeat;background-size:cover;height:240px;overflow:hidden;margin-bottom:92px;}
        .mt4_active p{font-size:48px;color:#fff;padding-top:60px;}
        .mt4_active .btn_down{background-image:linear-gradient(100deg,#fb515e,#fb694f),linear-gradient(#fff,#fff);border-radius:5px;font-size:20px;text-align:center;height:58px;line-height:58px;width:192px;float:right;color:#fff;margin-top:-20px;}
        .mt4 .mt4_down h2.title:before{left:30%;}
        .mt4 .mt4_down h2.title:after{right:34%;}
        .mt4_down{margin-bottom:104px;}
        .mt4_down ul{font-size:0;margin-left:-3%;margin-right:-3%;text-align:center;}
        .mt4_down ul li{margin-left:3%;margin-right:3%;width:19%;display:inline-block;vertical-align:top;border:1px solid #e7ecef;font-size:18px;color:#555;padding:30px 5px;text-align:center;border-radius:5px;}
        .mt4_down ul li img{vertical-align:middle;margin-right:15px;}

        /* 小尺寸 */
        .mt4_down .mt4_down_small{display:none;}
        .mt4_down .mt4_down_small ul li{width:36%;border:1px solid #979797;padding:50px 10px 30px;margin:0px 3%;}
        .mt4_down .mt4_down_small ul li div{min-height:120px;margin-bottom:40px;}
        .mt4_down .mt4_down_small ul li div img{margin:0;}
        .mt4_down .mt4_down_small ul li p{font-size:24px;color:#333;}
        .footer{text-align:center;background:#292b33;padding:50px 0px;}
        .footer p{line-height:1.8;color:#a6a6a6;font-size:16px;}
        .hide_form{display: none;}
        @media (max-width:1220px){
            .mt4_down ul,.mt4_advantage ul{margin-left:0;margin-right: 0;}
        }
        @media (max-width:1180px){
            .mt4 h2.title:before{left:12%;}
            .mt4 h2.title:after{right:14%;}
        }
        @media (max-width:1160px){
            .mt4_advantage ul li>img{width:80%;}
            .mt4_advantage ul li p{font-size:18px;}
            .mt4_advantage ul li h3{font-size:30px;}
            .mt4_advantage ul{margin-right:-1%;margin-left:-1%;}
            .mt4_advantage ul li{display:inline-block;width:23%;margin-right:1%;margin-left:1%;vertical-align:top;}
            .mt4_advantage ul li div{font-size:18px;}
        }
        @media (max-width:1120px){
            .mt4 .banner{height:600px;}
            .cui_free_right{margin-top:25%;}
            .fourth{left:45%;}

        }
        @media (max-width:1180px){
            .mt4 h2.title:before{left:10%;}
            .mt4 h2.title:after{right:12%;}
        }
        @media (max-width:1050px){
            .mt4_active{height:200px;}
            .mt4 .mt4_down h2.title:before{left:26%;}
            .mt4 .mt4_down h2.title:after{right:28%;}
            .mt4_down ul li{margin-left:1%;margin-right:1%;width:23%;}
            .mt4_down ul{margin-left:0;margin-right:0;}
        }
        @media (max-width:992px){
            .fourth{left:45%;width:520px;}
            #myModal h3,
            #myModal h3 span,
            .fourth h3,
            .fourth h3 span{font-size:38px;}
            .mt4 h2.title:before{left:8%;}
            .mt4 h2.title:after{right:10%;}
        }
        @media (max-width:930px){
            .mt4 h2.title:before{left:4%;}
            .mt4 h2.title:after{right:6%;}
            .mt4_advantage ul li p{font-size:16px;}
            .mt4_active{height:150px;}
            .mt4_active .btn_down{margin-top:-35px;}
            .mt4_active p{padding-top:50px;font-size:38px;}
            .mt4_down ul li{font-size:16px;}
        }
        @media (max-width:840px){
            .cui_free_right{margin-top:40px;}
            .banner_small{display:block;}
            .mt4 .banner{background:none;height:auto;}
            .fourth{padding-left:0px;position:initial;margin:0 auto;width:100%;}
            .cui_free_right h3{color:#2d2f39;}
            .fourth .form_text{color:#2d2f39!important;padding:0px 20px;}
            .box_big{display:none;}
            .box_small{display:block;}
            .mt4_major{display:none;}
            .mt4_active .btn_down{margin-top:0px;float:none;}
            .mt4_active{background:url("/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_active_small.jpg?v=1") bottom right no-repeat;height:257px;background-size:cover;margin-bottom:50px;}
            .mt4_active p{margin-bottom:26px;}
            .mt4_down .mt4_down_big{display:none;}
            .mt4_down .mt4_down_small{display:block;}
            .mt4_down{margin-bottom:50px;}
            .footer{background:#f1f5fb;padding:10px 0px;}
            .banner .gform_success{color:#2d2f39;}
        }
        @media (max-width:740px){
            .mt4 .box_small h2.title:before{left:12%;}
            .mt4 .box_small h2.title:after{right:16%;}
            .mt4_down .mt4_down_small ul li{width:44%;}
        }
        @media (max-width:650px){
            .mt4 .box_small h2.title:before{width:61px;height:65px;top:-40%;}
            .mt4 .box_small h2.title:after{width:39px;height:55px;top:-40%;}
            .box_small .mt4_advantage ul li p{margin-bottom:30px;}
            .mt4 .mt4_content .box_small .btn_down{height:50px;line-height:50px;font-size:24px;}
            .mt4 h2.title{margin-bottom:60px;font-size:30px;}
            .mt4_advantage ul{margin:0px 0px 40px;}
            .box_small .mt4_advantage ul li h3{font-size:24px;}
            .mt4_active{height:200px;background-size:cover;}
            .mt4_active p{font-size:30px;}
            .mt4_active .btn_down{font-size:18px;height:48px;line-height:48px;}
            .mt4_down .mt4_down_small ul li p{font-size:18px;}
            .mt4_down .mt4_down_small ul li{padding:30px 10px;}
            .mt4_down .mt4_down_small ul li div{margin-bottom:20px;}
            .modal-content{width:90%;}
        }
        @media (max-width:500px){
            .fourth input,
            .fourth button{width:90%;}
            .radio_box{right:10%;}
             #myModal h3,
            #myModal h3 span,
            .fourth h3,
            .fourth h3 span{font-size:30px;}
            .mt4 .box_small h2.title:before{left:4%;}
            .mt4 .box_small h2.title:after{right:8%;}
            .mt4_active{height:160px;}
            .mt4_active p{padding-top:28px;font-size:24px;}
            .mt4_active .btn_down{font-size:16px;height:40px;line-height:40px;}
        }
        @media (max-width:450px){
            .mt4_down .mt4_down_small ul li{width:80%;margin:0 auto;margin-bottom:30px;}
        }
        @media (max-width:400px){
            .mt4 .box_small h2.title:before{left:0%;}
            .mt4 .box_small h2.title:after{right:0%;}
            .mt4_active{background-position:left;}
            #myModal h3, #myModal h3 span, .fourth h3, .fourth h3 span {
                font-size: 26px;
            }
        }
        @media (max-width:350px){
            .mt4 .box_small h2.title:before{width:43px;height:46px;top:-20%;}
            .mt4 .box_small h2.title:after{width:27px;height:38px;top:-20%;}
        }

    </style>


    <div class="mt4">
        <div class="banner">
            <div class="banner_small">
                <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/banner_small.jpg" alt="">
            </div>
            <div class="box_big" style="max-width: 1200px;margin: auto;padding-top: 50px;">
                <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/logo.png"/>
            </div>
            <div class="banner_small" style="margin: auto;padding-top: 50px;text-align:center;">
                <img src="/wp-content/themes/FPMarkets/images/logo-205.png"/>
            </div>
            
            <div class="fourth">
                <div class="cui_free_right">
                 <div class="opacity033new" id="register-now" style="padding-top:24px;padding-bottom:24px;">   
                    <div class="registration">
					<div class="fp-demo-signup-global">
					<div class="form_signup_global_msg_ST text-center text-danger"></div>
					<form id="form_signup_global_ST" method="post" target="_blank">
					<input id="first_name_ST" name="first_name" value="" type="text" placeholder="名" class="ncform"/>
					<input id="last_name_ST" name="last_name" value="" type="text" placeholder="姓" class="ncform"/>
					<input id="email_ST" name="email" value="" type="text" placeholder="邮箱" class="ncform"/>
					<input id="phone_ST" name="phone" value="" type="text" placeholder="电话" class="ncform"/>
					<input id="platform_ST" name="platform" value="mt4" type="hidden"/>
					<input id="country_ST" name="country" value="CN" type="hidden"/>
					<input id="track_lang_ST" name="language" value="" type="hidden" value="int-EN"/>
					<input id="fpm-affiliate-pcode_ST" name="fpm-affiliate-pcode" value="Website/WLK" type="hidden"/>
					<input id="fpm-affiliate-utm-source_ST" name="fpm-affiliate-utm-source" value="Website" type="hidden"/>
					<input id="currency_ST" name="currency" value="USD" type="hidden"/>
					<input id="honeypot_ST" type="hidden" name="honeypot" value=""/>
					<input id="_mkto_trk_ST" type="hidden" value="" name="_mkto_trk"/>
					<input id="track1_1_ST" name="fpm-affiliate-pcode" value="Website/WLK" type="hidden"/>
					<input id="track2_1_ST" name="fpm-affiliate-utm-source" value="Website" type="hidden"/>
					<input id="track7_1_ST" name="cxd" value="" type="hidden"/>
					<input id="track7_2_ST" name="bta" value="" type="hidden"/>
					<input id="track_lang_ST" name="language" value="" type="hidden"/>
					<input id="track3_1_ST" name="fpm-affiliate-utm-campaign" value="" type="hidden"/>
					<input id="track4_1_ST" name="fpm-affiliate-utm-content" value="" type="hidden"/>
					<input id="track5_1_ST" name="fpm-affiliate-agt" value="" type="hidden"/>
					<input id="btn_name_get_ST" type="hidden" value="GET STARTED NOW" name="btn_name_get"/>
					<!-- <div id="recaptcha_ST" class="g-recaptcha" data-sitekey="6LedlCkUAAAAAOWdG2pMSm0cW6xn-bhM6odyCs2c" data-size="invisible"></div> -->
					<div class="fp-demo-submit-global"><input style="border-radius:0 10px 10px 10px!important;background:#f82f4a!important;" class="customBtnRed txt-bold" type="submit" value="立即注册"/></div>
					</form>
					</div>
					
                    </div>
                    </div>  
                    
                </div>
            </div>
        </div>
        <div class="mt4_content">
            <div class="inner box_big">
                <h2 class="title">MT4 — 大多数人使用的软件</h2>
                <div class="mt4_advantage">
                    <ul>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list1.png" alt="">
                            <h3>灵活方便</h3>
                            <p>众多模式<br>直观的图表行情<br>一键即可操作</p>
                            <div class="btn_down">
                                <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_download.png" alt="">
                                Windows下载
                            </div>
                        </li>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list2.png" alt="">
                            <h3>操作便捷</h3>
                            <p>实用便捷，<br>MT4操作系统简单易操作<br>&nbsp;</p>
                            <div class="btn_down">
                                <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_download.png" alt="">
                                iMac下载
                            </div>
                        </li>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list3.png" alt="">
                            <h3>多维度分析</h3>
                            <p>强大的图表分析上具和<br>指标详尽的报表<br>实时财经新闻</p>
                            <div class="btn_down">
                                <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_download.png" alt="">
                                iOS下载
                            </div>
                        </li>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list4.png" alt="">
                            <h3>新手学堂</h3>
                            <p>简单易学，经验交流，<br>让新人更快上手<br>&nbsp;</p>
                            <div class="btn_down">
                                <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_download.png" alt="">
                                Android下载
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="inner box_small">
                <h2 class="title title_hide">MT4四大优势</h2>
                <div class="mt4_advantage">
                    <ul>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list4.png" alt="">
                            <h3>操作便捷</h3>
                            <p>人性化界面 简单实用</p>
                        </li>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list3.png" alt="">
                            <h3>全面兼容</h3>
                            <p>适合多操作系统使用</p>
                        </li>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list2.png" alt="">
                            <h3>工具齐全</h3>
                            <p>多类型技术指标工具</p>
                        </li>
                        <li>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_advantage_list1.png" alt="">
                            <h3>免费下载</h3>
                            <p>一键免费下载MT4</p>
                        </li>
                    </ul>
                    <div class="btn_down">立即下载MT4</div>
                </div>
            </div>
        </div>
        <div class="mt4_major">
            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/major_new.jpg" alt="">
        </div>
        <div class="mt4_active">
            <div class="inner">
                <p>免费下载mt4软件</p>
                <div class="btn_down">
                    免费下载领取
                </div>
            </div>
        </div>
        <div class="mt4_down">
            <div class="inner mt4_down_big">
                <h2 class="title">下载 MT4</h2>
                <ul>
                    <li class="btn_down">
                        <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_down_ios.png" alt="">
                         iOS下载
                    </li>
                    <li class="btn_down">
                        <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_down_android.png" alt="">
                         Android下载
                    </li>
                    <li class="btn_down">
                        <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_down_windows.png" alt="">
                         Windows下载
                    </li>
                    <li class="btn_down">
                        <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_down_imac.png" alt="">
                         iMac下载
                    </li>
                </ul>
            </div>
            <div class="inner mt4_down_small">
                <ul>
                    <li class="btn_down">
                        <div>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_down_ios_small.png" alt="">
                        </div>
                         <p>Android免费下载 &gt;</p>
                    </li>
                    <li class="btn_down">
                        <div>
                            <img src="/wp-content/themes/FPMarkets/assets/baidu-lp/mt4-fpm/mt4_down_android_small.png" alt="">
                        </div>
                         <p>iOS免费下载 &gt;</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer">
        <p>投资有风险，入市需谨慎</p>
    </div>
    

</body>



<?php wp_footer(); ?> 


<!-- GLOBAL FORM SIGN UP -->
<!-- <script src="https://www.google.com/recaptcha/api.js" async ></script> -->
<script src="https://fpmarketsinternational.com/content/lp/js/js.cookie.js" ></script>
<script src="https://fpmarketsinternational.com/content/lp/js/i1502958122408_jquery.validate.js" ></script>
<script> 
function GetURLParameter(sParam) {
    var sPageURL = decodeURIComponent( window.location.search.substring(1));

    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) {
            return sParameterName[1];
        }
    }
}
function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
}
    
jQuery(document).ready(function($) {

    var track1 = GetURLParameter('fpm-affiliate-url');
    var track2 = GetURLParameter('fpm-affiliate-pcode');
    var track3 = GetURLParameter('fpm-affiliate-utm-source');
    var track4 = GetURLParameter('fpm-affiliate-utm-campaign');
    var track5 = GetURLParameter('affiliate-utm-content');
    var track6 = GetURLParameter('pcode');


    var url1 = 'https://portal.fpmarketsinternational.com/register';

    if (GetURLParameter('language') === 'es') {
        url1 = 'https://portal.fpmarketsinternational.com/es/register';
    }

    var newUrl = url1 + "?fpm-affiliate-url=" + track1 + "&fpm-affiliate-pcode=" + track2 + "&fpm-affiliate-utm-source=" + track3 + "&fpm-affiliate-utm-campaign=" + track4 + "&affiliate-utm-content=" + track5 + "&pcode=" + track6;
    jQuery("a.directions-link1").attr("href", newUrl);
    jQuery("a.directions-link1").attr("onclick", 'goog_report_conversion("' + newUrl + '")');

    var lang = jQuery('html').attr('lang');
    
    var langParam = getUrlParameter('language');

    // language from ulr parameters has priority
    if (langParam) {
        lang = langParam;
    }								

    $("#form_signup_global #country").val("CN");

    var countryCodes_global = { "AD": "+376", "AE": "+971", "AF": "+93", "AG": "+1268", "AI": "+1264", "AL": "+355", "AM": "+374", "AN": "+599", "AO": "+244", "AR": "+54", "AS": "+685", "AT": "+43", "AU": "+61", "AW": "+297", "AZ": "+994", "BA": "+387", "BB": "+1246", "BD": "+880", "BE": "+32", "BF": "+226", "BG": "+359", "BH": "+973", "BI": "+257", "BJ": "+229", "BL": "+590", "BM": "+1441", "BN": "+673", "BO": "+591", "BR": "+55", "BS": "+1242", "BT": "+975", "BW": "+267", "BY": "+375", "BZ": "+501", "CA": "+1", "CC": "+6189162", "CD": "+243", "CF": "+236", "CG": "+242", "CH": "+41", "CI": "+225", "CK": "+682", "CL": "+56", "CM": "+237", "CN": "+86", "CO": "+57", "CR": "+506", "CU": "+53", "CV": "+238", "CY": "+357", "CZ": "+420", "DE": "+49", "DJ": "+253", "DK": "+45", "DM": "+1767", "DO": "+18", "DZ": "+213", "EC": "+593", "EE": "+372", "EG": "+20", "EH": "+212528", "ER": "+291", "ES": "+34", "ET": "+251", "FI": "+358", "FJ": "+679", "FK": "+500", "FM": "+691", "FO": "+298", "FR": "+33", "GA": "+241", "GB": "+44", "GD": "+1473", "GE": "+995", "GF": "+594", "GG": "+44", "GH": "+233", "GI": "+350", "GL": "+299", "GM": "+220", "GN": "+224", "GP": "+590", "GQ": "+240", "GR": "+30", "GS": "+500", "GT": "+502", "GU": "+1671", "GW": "+245", "GY": "+592", "HK": "+852", "HN": "+504", "HR": "+385", "HT": "+509", "HU": "+36", "ID": "+62", "IE": "+353", "IL": "+972", "IM": "+44", "IN": "+91", "IO": "+246", "IQ": "+964", "IR": "+98", "IS": "+354", "IT": "+39", "JE": "+441534", "JM": "+1876", "JO": "+962", "JP": "+81", "KE": "+254", "KG": "+996", "KH": "+855", "KI": "+686", "KM": "+269", "KN": "+1869", "KP": "+850", "KR": "+82", "KW": "+965", "KY": "+1345", "KZ": "+7", "LA": "+856", "LB": "+961", "LC": "+1758", "LI": "+423", "LK": "+94", "LR": "+231", "LS": "+266", "LT": "+370", "LU": "+352", "LV": "+371", "LY": "+218", "MA": "+212", "MC": "+377", "MD": "+373", "ME": "+382", "MF": "+590", "MG": "+261", "MH": "+692", "MK": "+389", "ML": "+223", "MM": "+95", "MN": "+976", "MO": "+853", "MP": "+1670", "MQ": "+596", "MR": "+222", "MS": "+1664", "MT": "+356", "MU": "+230", "MV": "+960", "MW": "+265", "MX": "+52", "MY": "+60", "MZ": "+258", "NA": "+264", "NC": "+687", "NE": "+227", "NF": "+672", "NG": "+234", "NI": "+505", "NL": "+31", "NO": "+47", "NP": "+977", "NR": "+674", "NU": "+683", "NZ": "+64", "OM": "+968", "PA": "+507", "PE": "+51", "PF": "+689", "PG": "+675", "PH": "+63", "PK": "+92", "PL": "+48", "PM": "+508", "PN": "+64", "PR": "+1", "PS": "+970", "PT": "+351", "PW": "+680", "PY": "+595", "QA": "+974", "RE": "+262", "RO": "+40", "RS": "+381", "RU": "+7", "RW": "+250", "SA": "+966", "SB": "+677", "SC": "+248", "SD": "+249", "SE": "+46", "SG": "+65", "SH": "+290", "SI": "+386", "SJ": "+47", "SK": "+421", "SL": "+232", "SM": "+378", "SN": "+221", "SO": "+252", "SR": "+597", "ST": "+239", "SV": "+503", "SY": "+963", "SZ": "+268", "TC": "+1649", "TD": "+235", "TF": "+689", "TG": "+228", "TH": "+66", "TJ": "+992", "TK": "+690", "TL": "+670", "TM": "+993", "TN": "+216", "TO": "+676", "TR": "+90", "TT": "+1868", "TV": "+688", "TW": "+886", "TZ": "+255", "UA": "+380", "UG": "+256", "UY": "+598", "UZ": "+998", "VA": "+39066", "VC": "+1784", "VE": "+58", "VG": "+1284", "VI": "+1340", "VN": "+84", "VU": "+678", "WF": "+681", "WS": "+685", "YE": "+967", "YT": "+262", "ZA": "+27", "ZM": "+260", "ZW": "+263" };

    
    $.get("https://ipinfo.io?token=8113c8e7b3e768", function(response) {
        $("#form_signup_global #country").val(response.country);
        $("#form_signup_global #phone").val(countryCodes_global[response.country]);
    }, "jsonp");

    $("#form_signup_global #country").change(function() {
        $("#form_signup_global #phone").val(countryCodes_global[$("#form_signup_global #country").val()]);
    });
    
    
	/* SIGN UP FORM 2 - START TRADING IN MINUTES */
	$("#form_signup_global_ST #country_ST").val("CN");

    $.get("https://ipinfo.io?token=8113c8e7b3e768", function(response) {
        //$("#form_signup_global_ST #country_ST").val(response.country);
        //$("#form_signup_global_ST #phone_ST").val(countryCodes_global[response.country]);
    }, "jsonp");

    $("#form_signup_global_ST #country_ST").change(function() {
        $("#form_signup_global_ST #phone_ST").val(countryCodes_global[$("#form_signup_global_ST #country_ST").val()]);
    });
	/* EO SIGN UP FORM 2 - START TRADING IN MINUTES */

    var translations = {
        'es': {
            'disclaimer': 'El Trading de CFD es riesgoso. Lee PDS en fpmarketsinternational.com AFSL286354',
            '1': 'PRACTICA TU TRADING',
            '2': 'CON UNA CUENTA DEMO DE FP MARKETS',
            '3': 'No te conformes con menos. Experimenta la emoción de operar en forex. Haz que FP Markets sea tu primera opción.',
            '4': 'ABRIR CUENTA DEMO',
            '5': 'Por que probar una cuenta DEMO con FP Markets?',
            '6': 'Afina tus habilidades de Trading',
            '7': 'Prueba y mejora tus habilidades. Descubre lo que funciona y lo que no; descarta cualquier error y aprende qué estrategias comerciales son rentables para ti. Sin costos, todo lo que necesitas es esfuerzo.',
            '8': 'Entiende la Plataforma',
            '9': 'Conoce tu plataforma de Trading completamente. Prueba cada función y botón para aprender a controlar y conocer todas las técnicas antes de dar el paso para abrir una cuenta real y depositar fondos.',
            '10': 'Aprende a manejar tus emociones',
            '11': 'Aprende a controlar tus emociones cuando realices operaciones de Trading. Ya sea por una pérdida o una ganancia, una cuenta demo es la manera perfecta de descubrir cómo puedes manejar tus emociones antes de embarcarte en tu experiencia de Trading real.',
            '12': 'Preguntas frecuentes',
            '13': 'Cual es el saldo mínimo para abrir una cuenta real?',
            '14': 'Para las cuentas CFD IRESS, el saldo mínimo de apertura es de $ 1,000 AUD o $ 1,000 en la moneda base. Para MT4, el saldo mínimo de apertura es de $ 100 AUD o $ 100 en la moneda base.',
            '15': 'Quien regula a FP Markets?',
            '16': 'FP Markets está regulada por la Comisión Australiana de Valores e Inversiones (ASIC) y opera bajo una Licencia de Servicios Financieros de Australia (AFSL) - número 286354. Los titulares de AFSL, como FP Markets, deben cumplir con muchas obligaciones permanentemente.',
            '17': 'Que tipos de cuentas puedo abrir?',
            '18': 'Apoyamos los siguientes tipos de cuentas: Individual, Joint, Sole Trader, Company, Trustee Individual y Corporate Trustee.',
            '19': 'Cuales son los horarios de soporte al cliente?',
            '20': 'Nuestro equipo de soporte a clientes está disponible las 24 horas del día.',
            '21': 'COMIENZA TU VIAJE HOY',

            's4-h-1':'Llámanos',
            's4-h-2':'Chat en vivo',
            's4-p-1':'Chat con ventas y soporte aquí',
            's4-a-1':'Chat en vivo ya',
            's4-h-3':'Email',
            's4-p-2':'Puedes escribirnos por email aquí',
            's4-h-4':'Siguenos',
            's4-p-3':'Únete a nuestra comunidad',
            's4-a-2':'Escribenos',
            's5-p': 'Mayor satisfacción general del cliente. Tendencias de Inversión 2016 Informe CFD de Australia. ' +
            'DESCARGO DE RESPONSABILIDAD: Este material en este sitio web está destinado a fines ilustrativos e ' +
            'información general solamente. No constituye asesoramiento financiero ni toma en cuenta sus objetivos ' +
            'de inversión, situación financiera o necesidades particulares. Comisiones, intereses, tarifas de plataforma, ' +
            'dividendos, margen de variación y otras tarifas y cargos pueden aplicarse a los productos o servicios ' +
            'financieros disponibles en FP Markets. La información en este sitio web se ha preparado sin tener en cuenta ' +
            'sus objetivos personales, su situación financiera o sus necesidades. Debe considerar la información a la luz ' +
            'de sus objetivos, situación financiera y necesidades antes de tomar una decisión acerca de si adquirir o ' +
            ' de cualquier producto financiero. Los contratos por diferencia (CFD) son derivados y pueden ser riesgosos; ' +
            'las pérdidas pueden exceder su pago inicial y debe ser capaz de cumplir con todas los gastos derivados tan ' +
            'pronto como se realicen. Al operar con CFD, usted no posee ni tiene ningún derecho sobre los activos ' +
            'subyacentes de los CFD. FP Markets recomienda que busque asesoramiento independiente de una persona ' +
            'debidamente calificada antes de decidir invertir o disponer de un derivado. Se puede obtener una ' +
            'Declaración de divulgación de productos para cada uno de los productos financieros disponibles de FP ' +
            'Markets ya sea desde este sitio web o a pedido en nuestras oficinas, y debe tenerse en cuenta antes de ' +
            'realizar transacciones con nosotros. First Prudential Markets Pty Ltd (ABN 16 112 600 281, AFS License ' +
            'No. 286354).',
            's5-p-2': 'FP Markets no acepta solicitudes de residentes de EE. UU., Japón o Nueva Zelanda o residentes de cualquier ' +
            '   otro país o jurisdicción donde dicha distribución o uso sea contrario a esas leyes o regulaciones locales.'
        }
    };

    if (translations[lang]) {
        for (var index in translations[lang]) {
            var element = jQuery('.trans-' + index);

            if (!element.length) {
                //console.log('Trans missing: ' + index);
                continue;
            }

            element.html(translations[lang][index]);
        }
    }
	
	/* SIGN UP FORM 2 - START TRADING IN MINUTES */
	$("#form_signup_global_ST #country_ST").val("CN");


    $("#form_signup_global_ST #country_ST").change(function() {
        $("#form_signup_global_ST #phone_ST").val(countryCodes_global[$("#form_signup_global_ST #country_ST").val()]);
    });
	/* EO SIGN UP FORM 2 - START TRADING IN MINUTES */
});
</script>
<script>
/* SIGN UP FORM VALIDATION */
var signupFormGlobal = "#form_signup_global";
var $ = jQuery.noConflict();
$(signupFormGlobal).validate({
    ignore: [],
    rules: {
        first_name: {
            required: true,
            minlength: 1,
        },
        last_name: {
            required: true,
        },
        email: {
            required: true,
            email: true
        },
        phone: {
            required: true,
        },
        country: {
            required: true,
        }
    },
    onfocusout: function(element) {
        $(element).valid();
    },
    errorClass: 'error',
    validClass: 'valid',
    errorElement: 'span',
    highlight: function(element, errorClass, validClass) {
        $(element).addClass(errorClass).removeClass(validClass);
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).removeClass(errorClass).addClass(validClass);
    },
    messages: {
        first_name: {
            required: "First name is required.",
        },
        last_name: {
            required: "Last name is required.",
        },
        email: {
            required: "Email is required.",
            email: "Please enter a valid email address",
        },
        phone: {
            required: "Phone is required."
        },
        country: {
            required: "Country is required."
        },
    },
    errorPlacement: function(error, element) {
        if ($(element).is("input")) {
           //error.insertAfter($(element));
        } else if ($(element).is("select")) {
            //error.insertAfter($(element).closest(".form-msg"));
        } else {
            //error.insertAfter(element)
        }
    },
    submitHandler: function(form) {

		var fpphone = $('#form_signup_global #phone').val();

		if( fpphone.match(/^[0-9]*$/) ){
			$('#form_signup_global #phone').removeClass('error').addClass('valid');
			$('.fp-demo-signup-global .form_signup_global_msg').html("");
		}
		else{
			$('#form_signup_global #phone').removeClass('valid').addClass('error');
			$('.fp-demo-signup-global .form_signup_global_msg').html("Please enter a valid phone number; only numeric value is expected.");
			return false;
		}
		
        $('.fp-demo-signup-global .form_signup_global_msg').html("");
        /* grecaptcha.execute();
        console.log("The captcha has been already solved"); */
        var honeypot = $('#form_signup_global #honeypot').val();
        if (honeypot != "") {
            alert('value is - >' + honeypot);
            return false;
        } else {
            function readCookie(name) {
                var cookiename = name + "=";
                var ca = document.cookie.split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                    if (c.indexOf(cookiename) == 0) return c.substring(cookiename.length, c.length);
                }
                return null;
            }
            var test_mydata = document.getElementById('_mkto_trk').value = readCookie('_mkto_trk');
            var chk_lang = GetURLParameter('language');
										   
            
            var fpm_affiliate_pcode = "fpm-affiliate-pcode";
            var fpm_affiliate_utm_source = "fpm-affiliate-utm-source";
            var fpm_affiliate_utm_campaign = "fpm-affiliate-utm-campaign";
            var fpm_affiliate_utm_content = "fpm-affiliate-utm-content";
            var fpm_affiliate_agt = "fpm-affiliate-agt";
            var bta_chk = $("#form_signup_global #track7_2").val();
            var bta_fianl_val = "";
            if (bta_chk === "") {
                bta_fianl_val = "0";
            } else {
                bta_fianl_val = $("#form_signup_global #track7_2").val();
            }
            var lang_chk = $("#form_signup_global #track_lang").val();
            var lang_fianl_val = "";
   
            if (lang_chk === "") {
	
										  
	 
                lang_fianl_val = "int-EN";
															
	 
							   
            } else {
	
                lang_fianl_val = $("#form_signup_global #track_lang").val();
            }
   
            var request = $.ajax({
                url: "https://portal.fpmarkets.com/api/demoRegister",
                type: "POST",
                data: {
                    first_name: $("#form_signup_global #first_name").val().toString(),
                    last_name: $("#form_signup_global #last_name").val().toString(),
                    email: $("#form_signup_global #email").val().toString(),
                    phone: $("#form_signup_global #phone").val().toString(),
                    platform: $("#form_signup_global #platform").val().toString(),
                    country: $("#form_signup_global #country").val().toString(),
                    currency: $("#form_signup_global #currency").val().toString(),
                    "fpm-affiliate-pcode": $("#form_signup_global #track1_1").val().toString(),
                    "fpm-affiliate-utm-source": $("#form_signup_global #track2_1").val().toString(),
                    "fpm-affiliate-utm-campaign": $("#form_signup_global #track3_1").val().toString(),
                    "fpm-affiliate-utm-content": $("#form_signup_global #track4_1").val().toString(),
                    "fpm-affiliate-agt": $("#form_signup_global #track5_1").val().toString(),
                    "_mkto_trk": $("#form_signup_global #_mkto_trk").val().toString(),
                    "cxd": $("#form_signup_global #track7_1").val().toString(),
                    "bta": bta_fianl_val.toString(),
                    "language": lang_fianl_val.toString(),
                },
                dataType: 'json',
                beforeSend: function( xhr ) {
                    $('#form_signup_global .fp-demo-submit-global input[type=submit]').val('Processing..');
                    $('#form_signup_global .fp-demo-submit-global input[type=submit]').attr('disabled', 'disabled');
                },
                success: function(msg) {
                    $('.fp-demo-signup-global .form_signup_global_msg').html("");

                    if (msg.success == true) {
                        var first_name = encodeURIComponent($("#first_name").val().toString()),
                        last_name = encodeURIComponent($("#last_name").val().toString()),
                        email = encodeURIComponent($("#email").val().toString()),
                        phone = encodeURIComponent($("#phone").val().toString()),
                        country = encodeURIComponent($("#country").val().toString());
						var fpURLstructure = 'fname='+first_name+'&lname='+last_name+'&email='+email+'&phone='+phone+'&actype=1&countrycode='+country;
                        
                        setTimeout(function() {
                            if (typeof(chk_lang) != "undefined" && chk_lang !== null) {

                                if (chk_lang == "es") {
                                    window.location = "/thank-you-application-baidu/";
									//window.location = "/thank-you-application-baidu/";
                                } else if (chk_lang == "aus") {
                                    window.location = "/thank-you-application-baidu/";
                                } else if (chk_lang == "en") {
                                    window.location = "/thank-you-application-baidu/";
                                }
                            } else {
																	   
		 
                                window.location = "/thank-you-application-baidu/";
																									
																											   
		 
																											   
                            }
                        })
                    } else {
                        $('.fp-demo-signup-global .form_signup_global_msg').html("This email address is already registered. Please enter a new email address.");
                        $('#form_signup_global .fp-demo-submit-global input[type=submit]').val('Register Now');
                        $('#form_signup_global .fp-demo-submit-global input[type=submit]').removeAttr('disabled');
                    }
                },
                error: function(msg, error) {
                    $('.fp-demo-signup-global .form_signup_global_msg').html("Please enter a valid phone number.");
                    $('#form_signup_global .fp-demo-submit-global input[type=submit]').val('Register Now');
                    $('#form_signup_global .fp-demo-submit-global input[type=submit]').removeAttr('disabled');
                        }
            }).done(function( data ) {
                /* $('#form_signup_global .fp-demo-submit-global input[type=submit]').val('Register Now');
                $('#form_signup_global .fp-demo-submit-global input[type=submit]').removeAttr('disabled'); */
            });
            return false;
        }
    }
});
$(signupFormGlobal + " button[type='submit']").click(function() {
    setTimeout(function() {
        $("input.error").first().focus();
    }, 50)
});
/* EO SIGN UP FORM VALIDATION */

/* SIGN UP FORM 2 VALIDATION - START TRADING IN MINUTES */
var signupFormGlobal_ST = "#form_signup_global_ST";
var $ = jQuery.noConflict();
$(signupFormGlobal_ST).validate({
    ignore: [],
    rules: {
        first_name: {
            required: true,
            minlength: 1,
        },
        last_name: {
            required: true,
        },
        email: {
            required: true,
            email: true
        },
        phone: {
            required: true,
        },
        country: {
            required: true,
        }
    },
    onfocusout: function(element) {
        $(element).valid();
    },
    errorClass: 'error',
    validClass: 'valid',
    errorElement: 'span',
    highlight: function(element, errorClass, validClass) {
        $(element).addClass(errorClass).removeClass(validClass);
    },
    unhighlight: function(element, errorClass, validClass) {
        $(element).removeClass(errorClass).addClass(validClass);
    },
    messages: {
        first_name: {
            required: "First name is required.",
        },
        last_name: {
            required: "Last name is required.",
        },
        email: {
            required: "Email is required.",
            email: "Please enter a valid email address",
        },
        phone: {
            required: "Phone is required."
        },
        country: {
            required: "Country is required."
        },
    },
    errorPlacement: function(error, element) {
        if ($(element).is("input")) {
           //error.insertAfter($(element));
        } else if ($(element).is("select")) {
            //error.insertAfter($(element).closest(".form-msg"));
        } else {
            //error.insertAfter(element)
        }
    },
    submitHandler: function(form) {
		var fpphone_ST = $('#form_signup_global_ST #phone_ST').val();

		/*if( fpphone_ST.match(/^[0-9]*$/) ){
			$('#form_signup_global_ST #phone_ST').removeClass('error').addClass('valid');
			$('.fp-demo-signup-global .form_signup_global_msg_ST').html("");
		}
		else{
			$('#form_signup_global_ST #phone_ST').removeClass('valid').addClass('error');
			$('.fp-demo-signup-global .form_signup_global_msg_ST').html("Please enter a valid phone number; only numeric value is expected.");
			return false;
		}*/
		
        $('.fp-demo-signup-global .form_signup_global_msg_ST').html("");
        /* grecaptcha.execute();
        console.log("The captcha has been already solved"); */
        var honeypot = $('#form_signup_global_ST #honeypot_ST').val();
        if (honeypot != "") {
            alert('value is - >' + honeypot);
            return false;
        } else {
            function readCookie(name) {
                var cookiename = name + "=";
                var ca = document.cookie.split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') c = c.substring(1, c.length);
                    if (c.indexOf(cookiename) == 0) return c.substring(cookiename.length, c.length);
                }
                return null;
            }
            var test_mydata = document.getElementById('_mkto_trk_ST').value = readCookie('_mkto_trk');
            var chk_lang = GetURLParameter('language');
										   
            
            var fpm_affiliate_pcode = "fpm-affiliate-pcode";
            var fpm_affiliate_utm_source = "fpm-affiliate-utm-source";
            var fpm_affiliate_utm_campaign = "fpm-affiliate-utm-campaign";
            var fpm_affiliate_utm_content = "fpm-affiliate-utm-content";
            var fpm_affiliate_agt = "fpm-affiliate-agt";
            var bta_chk = $("#form_signup_global_ST #track7_2_ST").val();
            var bta_fianl_val = "";
            if (bta_chk === "") {
                bta_fianl_val = "0";
            } else {
                bta_fianl_val = $("#form_signup_global_ST #track7_2_ST").val();
            }
            var lang_chk = $("#form_signup_global_ST #track_lang_ST").val();
            var lang_fianl_val = "";
   
            if (lang_chk === "") {
	
										  
	 
                lang_fianl_val = "int-EN";
															
	 
							   
            } else {
	
                lang_fianl_val = $("#form_signup_global_ST #track_lang_ST").val();
            }
   
            var request = $.ajax({
                url: "https://portal.fpmarkets.com/api/demoRegister",
                type: "POST",
                data: {
                    first_name: $("#form_signup_global_ST #first_name_ST").val().toString(),
                    last_name: $("#form_signup_global_ST #last_name_ST").val().toString(),
                    email: $("#form_signup_global_ST #email_ST").val().toString(),
                    phone: $("#form_signup_global_ST #phone_ST").val().toString(),
                    platform: $("#form_signup_global_ST #platform_ST").val().toString(),
                    country: $("#form_signup_global_ST #country_ST").val().toString(),
                    currency: $("#form_signup_global_ST #currency_ST").val().toString(),
                    "fpm-affiliate-pcode": $("#form_signup_global_ST #track1_1_ST").val().toString(),
                    "fpm-affiliate-utm-source": $("#form_signup_global_ST #track2_1_ST").val().toString(),
                    "fpm-affiliate-utm-campaign": $("#form_signup_global_ST #track3_1_ST").val().toString(),
                    "fpm-affiliate-utm-content": $("#form_signup_global_ST #track4_1_ST").val().toString(),
                    "fpm-affiliate-agt": $("#form_signup_global_ST #track5_1_ST").val().toString(),
                    "_mkto_trk": $("#form_signup_global_ST #_mkto_trk_ST").val().toString(),
                    "cxd": $("#form_signup_global_ST #track7_1_ST").val().toString(),
                    "bta": bta_fianl_val.toString(),
                    "language": lang_fianl_val.toString(),
                },
                dataType: 'json',
                beforeSend: function( xhr ) {
                    $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').val('Processing..');
                    $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').attr('disabled', 'disabled');
                },
                success: function(msg) {
                    $('.fp-demo-signup-global .form_signup_global_msg_ST').html("");

                    if (msg.success == true) {
                        var first_name = encodeURIComponent($("#first_name_ST").val().toString()),
                        last_name = encodeURIComponent($("#last_name_ST").val().toString()),
                        email = encodeURIComponent($("#email_ST").val().toString()),
                        phone = encodeURIComponent($("#phone_ST").val().toString()),
                        country = encodeURIComponent($("#country_ST").val().toString());
						var fpURLstructure = 'fname='+first_name+'&lname='+last_name+'&email='+email+'&phone='+phone+'&actype=1&countrycode='+country;
                        
                        setTimeout(function() {
                            if (typeof(chk_lang) != "undefined" && chk_lang !== null) {

                                if (chk_lang == "es") {
                                    window.location = "/thank-you-application-baidu/";
                                } else if (chk_lang == "aus") {
                                    window.location = "/thank-you-application-baidu/";
                                } else if (chk_lang == "en") {
                                    window.location = "/thank-you-application-baidu/";
                                }
                            } else {
											   
		 
																								
																									
																											   
		 
                                window.location = "/thank-you-application-baidu/";
                            }
                        })
                    } else {
                        $('.fp-demo-signup-global .form_signup_global_msg_ST').html("This email address is already registered. Please enter a new email address.");
                        $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').val('Register Now');
                        $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').removeAttr('disabled');
                    }
                },
                error: function(msg, error) {
                    $('.fp-demo-signup-global .form_signup_global_msg_ST').html("Please enter a valid phone number");
                    $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').val('Register Now');
                    $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').removeAttr('disabled');
                        }
            }).done(function( data ) {
                /* $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').val('Register Now');
                $('#form_signup_global_ST .fp-demo-submit-global input[type=submit]').removeAttr('disabled'); */
            });
            return false;
        }
    }
});
$(signupFormGlobal_ST + " button[type='submit']").click(function() {
    setTimeout(function() {
        $("input.error").first().focus();
    }, 50)
});
/* EO SIGN UP FORM 2 VALIDATION - START TRADING IN MINUTES  */

function parseQueryString() {
    var parsedParameters = {},
        uriParameters = location.search.substr(1).split('&');
    for (var i = 0; i < uriParameters.length; i++) {
        var parameter = uriParameters[i].split('=');
        var value = typeof(parameter[1]) !== 'undefined' ? parameter[1] : '';
        parsedParameters[parameter[0]] = decodeURIComponent(value);
    }
    return parsedParameters;
}

function getCookie(cname) {
   var name = cname + "=";
   var ca = document.cookie.split(';');
   for(var i = 0; i < ca.length; i++) {
       var c = ca[i];
       while (c.charAt(0) == ' ') {
           c = c.substring(1);
       }
       if (c.indexOf(name) == 0) {
           return c.substring(name.length, c.length);
       }
   }
   return "";
}

function convertAffiliateQueryStringToCookies() {
    var params = parseQueryString();
    for (var i in params) {
        if (params.hasOwnProperty(i) && (i.match(/fpm-affiliate/) || i.match(/bta/) || i.match(/cxd/) || i.match(/affiliate-utm-content/) || i.match(/language/))) {
            if (i.match(/bta/) || i.match(/cxd/)) {
				if( getCookie('fpm-affiliate-' + i) === "" ){
					document.cookie = 'fpm-affiliate-' + i + '=' + params[i] + '; path=/; domain=.' + window.location.host.split('.').slice(1).join('.')+';max-age=7776000';
					document.cookie = i + '=' + params[i] + '; path=/; domain=.' + window.location.host.split('.').slice(1).join('.')+';max-age=7776000';
				}
            } else
				if( getCookie(i) === "" ){
					document.cookie = i + '=' + params[i] + '; path=/; domain=.' + window.location.host.split('.').slice(1).join('.')+';max-age=7776000';
				}
        }
    }
}

jQuery(document).ready(function() {
    convertAffiliateQueryStringToCookies();
    //var track1 = GetURLParameter('fpm-affiliate-pcode');
    var track1 = typeof(GetURLParameter('fpm-affiliate-pcode')) !== 'undefined' ? GetURLParameter('fpm-affiliate-pcode') : '';
	track1 = getCookie('fpm-affiliate-pcode') !== "" ? getCookie('fpm-affiliate-pcode'): track1;
	
    //var track2 = GetURLParameter('fpm-affiliate-utm-source');
    var track2 = typeof(GetURLParameter('fpm-affiliate-utm-source')) !== 'undefined' ? GetURLParameter('fpm-affiliate-utm-source') : 'Website';
	track2 = getCookie('fpm-affiliate-utm-source') !== "" ? getCookie('fpm-affiliate-utm-source'): track2;
	
    var track3 = GetURLParameter('fpm-affiliate-utm-campaign');
	track3 = getCookie('fpm-affiliate-utm-campaign') !== "" ? getCookie('fpm-affiliate-utm-campaign'): track3;
	
    var track4 = GetURLParameter('fpm-affiliate-utm-content');
	track4 = getCookie('fpm-affiliate-utm-content') !== "" ? getCookie('fpm-affiliate-utm-content'): track4;
	
    var track5 = GetURLParameter('fpm-affiliate-agt');
	track5 = getCookie('fpm-affiliate-agt') !== "" ? getCookie('fpm-affiliate-agt'): track5;
	
    var track7_1 = GetURLParameter('cxd');
	track7_1 = getCookie('fpm-affiliate-cxd') !== "" ? getCookie('fpm-affiliate-cxd'): track7_1;
	
    var track7_2 = GetURLParameter('bta');
	track7_2 = getCookie('fpm-affiliate-bta') !== "" ? getCookie('fpm-affiliate-bta'): track7_2;
	
    var track8_1 = GetURLParameter('language');
	track8_1 = getCookie('language') !== "" ? getCookie('language'): track8_1;
	
										 

	$("#form_signup_global #track1_1").val(track1);
    $("#form_signup_global #track2_1").val(track2);
    $("#form_signup_global #track3_1").val(track3);
    $("#form_signup_global #track4_1").val(track4);
    $("#form_signup_global #track5_1").val(track5);
    $("#form_signup_global #track7_1").val(track7_1);
    $("#form_signup_global #track7_2").val(track7_2);
    $("#form_signup_global #track_lang").val(track8_1);
	
	$("#form_signup_global_ST #track1_1_ST").val(track1);
    $("#form_signup_global_ST #track2_1_ST").val(track2);
    $("#form_signup_global_ST #track3_1_ST").val(track3);
    $("#form_signup_global_ST #track4_1_ST").val(track4);
    $("#form_signup_global_ST #track5_1_ST").val(track5);
    $("#form_signup_global_ST #track7_1_ST").val(track7_1);
    $("#form_signup_global_ST #track7_2_ST").val(track7_2);
    $("#form_signup_global_ST #track_lang_ST").val(track8_1);
});
</script>


<script>
jQuery(document).ready(function($){
$("#form_signup_global #phone").on('keypress blur change keyup', function(e){
	var keyCode = (e.which)?e.which:e.keyCode
	return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$("#form_signup_global_ST #phone_ST").on('keypress blur change keyup', function(e){
	var keyCode = (e.which)?e.which:e.keyCode
	return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$("#form_signup_global_LP #phone_LP").on('keypress blur change keyup', function(e){
	var keyCode = (e.which)?e.which:e.keyCode
	return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$("#form_signup_global_LP2 #phone_LP2").on('keypress blur change keyup', function(e){
	var keyCode = (e.which)?e.which:e.keyCode
	return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$("#form_signup_global_LP #countrycode_LP").on('keypress blur change keyup', function(e){
	var keyCode = (e.which)?e.which:e.keyCode
	return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$("#form_signup_global_LP2 #countrycode_LP2").on('keypress blur change keyup', function(e){
	var keyCode = (e.which)?e.which:e.keyCode
	return !(keyCode>31 && (keyCode<48 || keyCode>57)); 
});

$("#form_signup_global #phone").attr("maxlength", "21");
$("#form_signup_global_ST #phone_ST").attr("maxlength", "21");
$("#form_signup_global_LP #phone_LP").attr("maxlength", "15");
$("#form_signup_global_LP2 #phone_LP2").attr("maxlength", "15");

$("#form_signup_global_LP #countrycode_LP").attr("maxlength", "6");
$("#form_signup_global_LP2 #countrycode_LP2").attr("maxlength", "6");

$("#form_new #countrycode").attr("maxlength", "6");
$("#form_new #phone").attr("maxlength", "15");
});
</script>



<link href="https://fonts.googleapis.com/css?family=Titillium+Web:200,300,400,600,700" rel="stylesheet">



<!--scripts starts here--> 
<script type="text/javascript" src="/wp-content/themes/FPMarkets/js/browser_selector.js"></script> 
<script type="text/javascript" src="/wp-content/themes/FPMarkets/js/jquery.validate.js"></script> 
<script type="text/javascript" src="/wp-content/themes/FPMarkets/js/script.js"></script> 
<!--scripts ends here-->
<script> 
//Form Validator
/*Validation For The Planner Step 1*/
//you can create your own Regular expression like we have done for the mobile number and make it true its name.
// allow user to enter number of Austrelia format [ if client have this requirement ]
//******** Add your form id here********
var formDefualt = "#form_new";
$(formDefualt).validate({
    
	//Ignore Field is for the Ignoring display None inputs validation
	ignore: [],
    rules: {
        first_name: {
            //******this is for the required field
			required: true,
			//******This option is for the minimum number of character
			minlength: 3,
		},
		last_name:{
            required: true,
		},
		email:{
            required: true,
			//******This option for the email address
			 email: true
		},
		phone:{
            required: true,
            //******it will allow users to enter number only
        },
        entityTypeId:{
            required: true,
        },
        country:{
            required: true,
        }
    },
    onfocusout: function (element) {
        $(element).valid();
    },
    errorClass: 'error',
    validClass: 'valid',
    errorElement: 'span',
    highlight: function (element, errorClass, validClass) { 
	    $(element).addClass(errorClass).removeClass(validClass);
    }, 
    unhighlight: function (element, errorClass, validClass) { 
	    $(element).removeClass(errorClass).addClass(validClass);
    },
    /*comment this code if you dont want messages*/
    messages: {
        first_name: {required: "This field is required.",},
		last_name:{required: "This field is required.",},
		email:{
			required: "This field is required.",
			email: "Please enter a valid email address",
		},
		phone:{required: "This field is required."},
        entityTypeId:{required: "This field is required."},
        country:{required: "This field is required."},
    },
    //***********comment this code if you dont want messages*/
	
	//Add your class instead of .form-msg (after that class error message will show)
	
	errorPlacement: function (error, element) {
        if ($(element).is("input")) {
            error.insertAfter($(element));
        } 
		else if ($(element).is("select")) {
            error.insertAfter($(element).closest(".form-msg"));
        }
		else {
            error.insertAfter(element)
        }
	},
	//*******In windows.location you can put your link where you want to redirect your form.

  	submitHandler: function (form) {

        //Empty out error messages.
		$('.email_msg').html("");

		
		//Basics.
		var honeypot = $('#honeypot').val();
        var errorMessageContainerHeight = '10px';
        var remoteErrorMessage = 'Unable to process request at the time. Please try again later.';
        var messagesSeparator = '<br>';

		if(honeypot !="") {
			alert('value is - >'+honeypot);
			return false;
		} else {
			/*cookie*/
			function readCookie(name) {
                var cookiename = name + "=";
                var ca = document.cookie.split(';');
                for (var i=0; i<ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0)==' ') c = c.substring(1,c.length);
                    if (c.indexOf(cookiename) == 0) return c.substring(cookiename.length,c.length);
                }
                return null;
			}
			var test_mydata = document.getElementById('_mkto_trk').value = readCookie('_mkto_trk');
			/* cookie */

			// Get language.
			var chk_lang = GetURLParameter('language');

			// $('.loader').css('display','block');

			// Change submit button UI.
			$("#thebutton span").text("Please wait...");
			$("#thebutton span").addClass("loaderimg");
			$("#thebutton").prop('disabled', true).addClass('btn-disable');

			var fpm_affiliate_pcode = "fpm-affiliate-pcode";
			var fpm_affiliate_utm_source = "fpm-affiliate-utm-source";
			var fpm_affiliate_utm_campaign = "fpm-affiliate-utm-campaign";
			var fpm_affiliate_utm_content = "fpm-affiliate-utm-content";
			var fpm_affiliate_agt = "fpm-affiliate-agt";

			var bta_chk =  $("#track7_2").val();
			var bta_fianl_val = "";
			if(bta_chk === "") {
				bta_fianl_val = "0";
			} else {
				bta_fianl_val =  $("#track7_2").val();
			}

			var lang_chk = $("#track_lang").val();
			var lang_fianl_val = "";
            if(lang_chk === "") {
                lang_fianl_val = "int-EN";
            } else {
                lang_fianl_val =  $("#track_lang").val();
            }

			var request = $.ajax({
				  url: "https://portal.fpmarkets.com/api/register",
				  type: "POST",
				  data: {
						first_name:$("#first_name").val().toString(),
						last_name:$("#last_name").val().toString(),
						email:$("#email").val().toString(),
						phone:$("#phone").val().toString(),
						platform:$("#platform").val().toString(),
                        country: $("#user_country").val().toString(),
                        entityTypeId: $("#entity_type_id").val().toString(),
						currency:$("#currency").val().toString(),
						"fpm-affiliate-pcode":$("#track1_1").val().toString(),
						"fpm-affiliate-utm-source":$("#track2_1").val().toString(),
						"fpm-affiliate-utm-campaign":$("#track3_1").val().toString(),
						"fpm-affiliate-utm-content":$("#track4_1").val().toString(),
						"fpm-affiliate-agt":$("#track5_1").val().toString(),
						"_mkto_trk":$("#_mkto_trk").val().toString(),
						"cxd":$("#track7_1").val().toString(),
						"bta":bta_fianl_val.toString(),
						"language":lang_fianl_val.toString(),
					},
				 dataType:'json',
				 success: function(response){
					 $('.email_msg').html("");
					 $('.loader').css('display','none');

                     //Now let's check if it was success?
                     if ( response.success == true ) {

                         //If it's a page redirection?
                         if ( response.redirectToUrl != '' ) {
                             window.location = response.redirectTo;

                         } else {
                             //Change form action url and submit it.
                             $(formDefualt).attr('action', response.redirectTo);
                             form.submit();
                         }

                     } else {
                         //Remove processing from submit button.
                         var btn_name_get = $('#btn_name_get').val();
                         $("#thebutton span").text(btn_name_get);
                         $("#thebutton span").removeClass("loaderimg");
                         $("#thebutton").prop('disabled', false).removeClass('btn-disable');

                         //If we have messages?
                         var messages = response.messages;
                         var messagesLength = messages.length;
                         if ( messagesLength > 0 ) {

                             //Add margin bottom to email_msg div.
                             $(".email_msg").css('margin-bottom', errorMessageContainerHeight);

                             //Iteration.
                             for (var i = 0; i < messagesLength; i++) {
                                 $('.email_msg').append(messages[i] + messagesSeparator);
                             }
                         } else {
                             $('.email_msg').append(remoteErrorMessage + messagesSeparator);
                         }
                     }
						
				},
				error: function(response){
                    $('.email_msg').html("");
					$('.loader').css('display','none');

					var btn_name_get = $('#btn_name_get').val();
					$("#thebutton span").text(btn_name_get);
					$("#thebutton span").removeClass("loaderimg");
					$("#thebutton").prop('disabled', false).removeClass('btn-disable');

					// Add margin bottom to email_msg div.
                    $(".email_msg").css('margin-bottom', errorMessageContainerHeight);

					//Response.
                    var data = response.responseJSON;

					// Check if we have an object here?
                    if ( response.status == 422 && data !== null && typeof data === 'object' ) {

                        //Iterate all and append to html errors.
                        for (var key in data) {
                            if (data.hasOwnProperty(key)) {
                                $('.email_msg').append(data[key][0] + messagesSeparator);
                            };
                        }
                    } else {
                        $('.email_msg').append(remoteErrorMessage + messagesSeparator);
                    }
				}
			});

			return false;
		}
    }
});
    
//**********On Submit form will be submit 
$(formDefualt + " button[type='submit']").click(function () {
    setTimeout(function () {
        $("input.error").first().focus();
    }, 50)
});


//**********GetURLParameter
function GetURLParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) {
            return sParameterName[1];
        }
    }
}

function parseQueryString() 
{ 
  var parsedParameters = {}, uriParameters = location.search.substr(1).split('&');
  for (var i = 0; i < uriParameters.length; i++)
  { 
   var parameter = uriParameters[i].split('='); 
   var value = typeof(parameter[1]) !== 'undefined' ? parameter[1] : ''; 
   parsedParameters[parameter[0]] = decodeURIComponent(value); 
  } 
  return parsedParameters;
 }/** Convert query params into cookie params */
    
    
function convertAffiliateQueryStringToCookies() {
    var params = parseQueryString();
    for (var i in params) {
        if (params.hasOwnProperty(i) && (i.match(/fpm-affiliate/) || i.match(/bta/) || i.match(/cxd/) || i.match(/affiliate-utm-content/) || i.match(/language/))) {
            if (i.match(/bta/) || i.match(/cxd/)) {
				if( getCookie('fpm-affiliate-' + i) === "" ){
					document.cookie = 'fpm-affiliate-' + i + '=' + params[i] + '; path=/; domain=.' + window.location.host.split('.').slice(1).join('.')+';max-age=7776000';
					document.cookie = i + '=' + params[i] + '; path=/; domain=.' + window.location.host.split('.').slice(1).join('.')+';max-age=7776000';
				}
            } else
				if( getCookie(i) === "" ){
					document.cookie = i + '=' + params[i] + '; path=/; domain=.' + window.location.host.split('.').slice(1).join('.')+';max-age=7776000';
				}
        }
    }
}
   
   
$(document).ready(function () {

   convertAffiliateQueryStringToCookies();   	
  
      //set default country as AU 
     $("#user_country").val('CN'); 	
  
    // Get country from IP.
    $.get("https://ipinfo.io?token=8113c8e7b3e768", function(response) {
        $("#user_country").val(response.country);
    }, "jsonp");
    
    //set default country as AU 
     $("#user_country2").val('CN'); 	
  
    // Get country from IP.
    $.get("https://ipinfo.io?token=8113c8e7b3e768", function(response) {
        $("#user_country2").val(response.country);
    }, "jsonp");
  

    var track1 = GetURLParameter('fpm-affiliate-pcode');
    var track2 = GetURLParameter('fpm-affiliate-utm-source');
    var track3 = GetURLParameter('fpm-affiliate-utm-campaign');
    var track4 = GetURLParameter('fpm-affiliate-utm-content');
    var track5 = GetURLParameter('fpm-affiliate-agt');

    var track7_1 = GetURLParameter('cxd');
    var track7_2 = GetURLParameter('bta');
    var track8_1 = GetURLParameter('language');

    $("#track1_1").val(track1);
    $("#track2_1").val(track2);
    $("#track3_1").val(track3);
    $("#track4_1").val(track4);
    $("#track5_1").val(track5);
    $("#track7_1").val(track7_1);
    $("#track7_2").val(track7_2);
    $("#track_lang").val(track8_1);
}); 
    
</script>

</body>

</html>