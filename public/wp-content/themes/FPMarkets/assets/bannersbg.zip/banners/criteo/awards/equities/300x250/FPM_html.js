(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"FPM_html_atlas_", frames: [[942,38,20,24],[0,307,126,21],[973,0,32,32],[900,306,124,22],[802,140,209,61],[992,225,20,21],[974,76,41,19],[0,0,300,250],[363,307,45,14],[802,246,188,24],[942,76,30,32],[984,203,21,20],[604,0,196,250],[1007,0,2,31],[788,272,110,37],[302,0,300,250],[802,203,180,41],[1003,97,21,21],[0,252,271,53],[273,252,271,53],[546,252,240,53],[181,307,79,11],[900,272,86,32],[942,110,59,16],[262,307,52,14],[942,0,29,36],[973,34,25,40],[802,0,138,138],[128,307,51,18],[1000,34,22,35],[316,307,45,16]]}
];


// symbols:



(lib.AppleLogoblack = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CFDTradingisriskyReadPDSatfpmarketscomAFSL286354 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.fblogo = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.fpmarketslogonegativehorizontalRGB = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Golongorshortinglobalmarkets = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.googlelogo = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.hkexlogo = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Layer1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Layer2 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Leverageupto201 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Microsoftlogoandwordmarkcopy = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle10copy4 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.RoundedRectangle1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.shutterstock_1434701594 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.t3b = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.teslalogo = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Trade10000stockCFDsonthebiggestexchanges = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Trade10000stockCFDsonthebiggestexchanges_1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.TradeAppleFacebookTeslaandmanymore = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.tradenow = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.trustpilot = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_1_1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_1_2 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_2 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_2_1 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_3 = function() {
	this.initialize(ss["FPM_html_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.AppleLogoblack();
	this.instance.setTransform(-10,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-12,20,24);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fblogo();
	this.instance.setTransform(-16,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16,-16,32,32);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.teslalogo();
	this.instance.setTransform(-10.5,-10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.5,-10.5,21,21);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.googlelogo();
	this.instance.setTransform(-10,-10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10.5,20,21);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Layer2();
	this.instance.setTransform(-22.5,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-7,45,14);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Microsoftlogoandwordmarkcopy();
	this.instance.setTransform(-10.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.5,-10,21,20);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_1_2();
	this.instance.setTransform(-69,-69);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69,-69,138,138);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_2_1();
	this.instance.setTransform(-11,-17.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11,-17.5,22,35);


(lib.Tween13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_3();
	this.instance.setTransform(-22.5,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-8,45,16);


(lib.Tween12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.hkexlogo();
	this.instance.setTransform(-20.5,-9.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.5,-9.5,41,19);


(lib.Tween11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_1();
	this.instance.setTransform(-26,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-7,52,14);


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject1();
	this.instance.setTransform(-14.5,-18);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.5,-18,29,36);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fpmarketslogonegativehorizontalRGB();
	this.instance.setTransform(-62,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62,-11,124,22);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tradenow();
	this.instance.setTransform(-39.5,-5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.5,-5.5,79,11);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CFDTradingisriskyReadPDSatfpmarketscomAFSL286354();
	this.instance.setTransform(-63,-10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-10.5,126,21);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rectangle10copy4();
	this.instance.setTransform(-1,-15.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-15.5,2,31);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.trustpilot();
	this.instance.setTransform(-43,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43,-16,86,32);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shutterstock_1434701594();
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Layer1();
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-125,300,250);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rectangle1();
	this.instance.setTransform(-98,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98,-125,196,250);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_1_1();
	this.instance.setTransform(-12.5,-20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol22, new cjs.Rectangle(-12.5,-20,25,40), null);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_2();
	this.instance.setTransform(-25.5,-9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(-25.5,-9,51,18), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject();
	this.instance.setTransform(-29.5,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(-29.5,-8,59,16), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.t3b();
	this.instance.setTransform(-90,-20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(-90,-20.5,180,41), null);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Trade10000stockCFDsonthebiggestexchanges();
	this.instance.setTransform(-135.5,-26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(-135.5,-26.5,271,53), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Golongorshortinglobalmarkets();
	this.instance.setTransform(-104.5,-30.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(-104.5,-30.5,209,61), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leverageupto201();
	this.instance.setTransform(-94,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(-94,-12,188,24), null);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.RoundedRectangle1();
	this.instance.setTransform(-55,-18.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol15, new cjs.Rectangle(-55,-18.5,110,37), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TradeAppleFacebookTeslaandmanymore();
	this.instance.setTransform(-120,-26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(-120,-26.5,240,53), null);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.setTransform(-15,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(-15,-16,30,32), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Trade10000stockCFDsonthebiggestexchanges_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,271,53), null);


// stage content:
(lib.FPM_html = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Trade_10_000__stock_CFDs__on_the_biggest_exchanges
	this.instance = new lib.Symbol1();
	this.instance.setTransform(149.5,104.5,1,1,0,0,0,135.5,26.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},16).wait(26).to({alpha:0},13).to({_off:true},1).wait(422));

	// logo
	this.instance_1 = new lib.Symbol13();
	this.instance_1.setTransform(152,95);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(72).to({_off:false},0).to({alpha:1},11).wait(27).to({alpha:0},13).to({_off:true},1).wait(354));

	// Vector_Smart_Object1
	this.instance_2 = new lib.Tween10("synched",0);
	this.instance_2.setTransform(94.5,139);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(56).to({_off:false},0).to({alpha:1},14).to({startPosition:0},40).to({alpha:0},13).to({_off:true},1).wait(354));

	// Vector_Smart_Object
	this.instance_3 = new lib.Tween11("synched",0);
	this.instance_3.setTransform(204,141);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(56).to({_off:false},0).to({alpha:1},14).to({startPosition:0},40).to({alpha:0},13).to({_off:true},1).wait(354));

	// hkexlogo
	this.instance_4 = new lib.Tween12("synched",0);
	this.instance_4.setTransform(82.5,75.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(56).to({_off:false},0).to({alpha:1},14).to({startPosition:0},40).to({alpha:0},13).to({_off:true},1).wait(354));

	// Vector_Smart_Object_3
	this.instance_5 = new lib.Tween13("synched",0);
	this.instance_5.setTransform(216.5,67);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(56).to({_off:false},0).to({alpha:1},14).to({startPosition:0},40).to({alpha:0},13).to({_off:true},1).wait(354));

	// Vector_Smart_Object_2
	this.instance_6 = new lib.Tween14("synched",0);
	this.instance_6.setTransform(153,32.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(56).to({_off:false},0).to({alpha:1},14).to({startPosition:0},40).to({alpha:0},13).to({_off:true},1).wait(354));

	// Vector_Smart_Object_1
	this.instance_7 = new lib.Tween15("synched",0);
	this.instance_7.setTransform(152,92);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(56).to({_off:false},0).to({alpha:1},14).to({startPosition:0},40).to({alpha:0},13).to({_off:true},1).wait(354));

	// Microsoft_logo_and_wordmark_copy
	this.instance_8 = new lib.Tween17("synched",0);
	this.instance_8.setTransform(152.5,146);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(170).to({_off:false},0).to({alpha:1},19).to({startPosition:0},18).to({alpha:0},13).to({_off:true},1).wait(257));

	// Layer_2
	this.instance_9 = new lib.Tween18("synched",0);
	this.instance_9.setTransform(232.5,148);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(177).to({_off:false},0).to({alpha:1},12).to({startPosition:0},18).to({alpha:0},13).to({_off:true},1).wait(257));

	// google_logo
	this.instance_10 = new lib.Tween19("synched",0);
	this.instance_10.setTransform(71,145.5);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(163).to({_off:false},0).to({alpha:1},26).to({startPosition:0},18).to({alpha:0},13).to({_off:true},1).wait(257));

	// tesla_logo
	this.instance_11 = new lib.Tween20("synched",0);
	this.instance_11.setTransform(232.5,103.5);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(156).to({_off:false},0).to({alpha:1},33).to({startPosition:0},18).to({alpha:0},13).to({_off:true},1).wait(257));

	// fb_logo
	this.instance_12 = new lib.Tween21("synched",0);
	this.instance_12.setTransform(151,103);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(149).to({_off:false},0).to({alpha:1},40).to({startPosition:0},18).to({alpha:0},13).to({_off:true},1).wait(257));

	// Apple_Logo_black
	this.instance_13 = new lib.Tween23("synched",0);
	this.instance_13.setTransform(69,102);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(144).to({_off:false},0).to({alpha:1},45).to({startPosition:0},18).to({alpha:0},13).to({_off:true},1).wait(257));

	// Trade_Apple__Facebook__Tesla_and_many_more__
	this.instance_14 = new lib.Symbol14();
	this.instance_14.setTransform(150,48.5);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(129).to({_off:false},0).to({alpha:1},15).wait(63).to({alpha:0},13).to({_off:true},1).wait(257));

	// Leverage_up_to_20_1
	this.instance_15 = new lib.Symbol16();
	this.instance_15.setTransform(150,122);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(230).to({_off:false},0).to({alpha:1},16).wait(20).to({alpha:0},11).to({_off:true},1).wait(200));

	// Go_long_or_short_in_global_markets
	this.instance_16 = new lib.Symbol17();
	this.instance_16.setTransform(150.5,67.5);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(222).to({_off:false},0).to({alpha:1},16).wait(28).to({alpha:0},11).to({_off:true},1).wait(200));

	// Trade_10_000__stock_CFDs__on_the_biggest_exchanges
	this.instance_17 = new lib.Symbol18();
	this.instance_17.setTransform(149.5,44.5);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(278).to({_off:false},0).to({alpha:1},19).wait(181));

	// t3b
	this.instance_18 = new lib.Symbol19();
	this.instance_18.setTransform(155,91.5);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(278).to({_off:false},0).to({alpha:1},29).to({alpha:0},9).to({alpha:1},10).to({alpha:0},10).to({alpha:1},10).to({alpha:0},10).to({alpha:1},10).to({alpha:0},10).to({alpha:1},10).to({alpha:0},10).to({alpha:1},7).wait(75));

	// Vector_Smart_Object
	this.instance_19 = new lib.Symbol20();
	this.instance_19.setTransform(248.5,139);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(309).to({_off:false},0).to({alpha:1},12).wait(157));

	// Vector_Smart_Object_2
	this.instance_20 = new lib.Symbol21();
	this.instance_20.setTransform(54.5,139);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(291).to({_off:false},0).to({alpha:1},11).wait(176));

	// Vector_Smart_Object_1
	this.instance_21 = new lib.Symbol22();
	this.instance_21.setTransform(149.5,139);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(301).to({_off:false},0).to({alpha:1},10).wait(167));

	// trustpilot
	this.instance_22 = new lib.Tween4("synched",0);
	this.instance_22.setTransform(60,226);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({startPosition:0},477).wait(1));

	// Rectangle_10_copy_4
	this.instance_23 = new lib.Tween5("synched",0);
	this.instance_23.setTransform(130,231.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).to({startPosition:0},477).wait(1));

	// CFD_Trading_is_risky__Read_PDS__at_fpmarkets_com_AFSL286354
	this.instance_24 = new lib.Tween6("synched",0);
	this.instance_24.setTransform(218,233.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).to({startPosition:0},477).wait(1));

	// trade_now
	this.instance_25 = new lib.Tween7("synched",0);
	this.instance_25.setTransform(218.5,194.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).to({startPosition:0},477).wait(1));

	// Rounded_Rectangle_1
	this.instance_26 = new lib.Symbol15();
	this.instance_26.setTransform(219,194.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(410).to({alpha:0},11).to({alpha:1},10).to({alpha:0},11).to({alpha:1},10).to({alpha:0},12).to({alpha:1},13).wait(1));

	// fpmarkets_logo_negative_horizontal_RGB
	this.instance_27 = new lib.Tween9("synched",0);
	this.instance_27.setTransform(80,193);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).to({startPosition:0},477).wait(1));

	// Rectangle_1
	this.instance_28 = new lib.Tween1("synched",0);
	this.instance_28.setTransform(98,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).to({startPosition:0},477).wait(1));

	// Layer_1
	this.instance_29 = new lib.Tween2("synched",0);
	this.instance_29.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_29).to({startPosition:0},477).wait(1));

	// shutterstock_1434701594
	this.instance_30 = new lib.Tween3("synched",0);
	this.instance_30.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_30).to({startPosition:0},477).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,125,150,125);
// library properties:
lib.properties = {
	id: '3E2F1914906B4A869165C192CB5C9937',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/FPM_html_atlas_.png", id:"FPM_html_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3E2F1914906B4A869165C192CB5C9937'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;