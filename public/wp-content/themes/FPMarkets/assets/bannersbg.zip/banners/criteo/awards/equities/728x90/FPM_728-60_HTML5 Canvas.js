(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"FPM_728_60_HTML5 Canvas_atlas_", frames: [[946,196,20,24],[841,174,126,20],[798,177,32,32],[912,98,100,52],[444,184,352,24],[1000,152,20,21],[0,0,728,90],[81,208,45,14],[841,152,157,20],[1003,23,21,20],[1016,45,1,67],[730,138,109,37],[0,92,728,90],[730,98,180,38],[1003,0,21,21],[730,0,271,49],[730,51,248,45],[0,184,442,22],[0,208,79,11],[832,196,59,16],[980,51,34,41],[969,174,25,40],[893,196,51,18]]}
];


// symbols:



(lib.AppleLogoblack = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CFDTradingisriskyReadPDSatfpmarketscomAFSL286354 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.fblogo = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.fpmarketslogonegativestackedRGB = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Golongorshortinglobalmarkets = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.googlelogo = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Layer1 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Layer2 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Leverageupto201 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Microsoftlogoandwordmarkcopy = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle10copy4 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.RoundedRectangle1 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.shutterstock_1434701594 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.t3b = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.teslalogo = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Trade10000stockCFDsonthebiggestexchanges = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Trade10000stockCFDsonthebiggestexchanges_1 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.TradeAppleFacebookTeslaandmanymore = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.tradenow = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject1 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_1 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.VectorSmartObject_2 = function() {
	this.initialize(ss["FPM_728_60_HTML5 Canvas_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.RoundedRectangle1();
	this.instance.setTransform(-54.5,-18.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol24, new cjs.Rectangle(-54.5,-18.5,109,37), null);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tradenow();
	this.instance.setTransform(-39.5,-5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol23, new cjs.Rectangle(-39.5,-5.5,79,11), null);


(lib.Symbol22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_1();
	this.instance.setTransform(-12.5,-20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol22, new cjs.Rectangle(-12.5,-20,25,40), null);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject_2();
	this.instance.setTransform(-25.5,-9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(-25.5,-9,51,18), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject();
	this.instance.setTransform(-29.5,-8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(-29.5,-8,59,16), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.t3b();
	this.instance.setTransform(-90,-19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(-90,-19,180,38), null);


(lib.Symbol18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Trade10000stockCFDsonthebiggestexchanges_1();
	this.instance.setTransform(-124,-22.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol18, new cjs.Rectangle(-124,-22.5,248,45), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.VectorSmartObject1();
	this.instance.setTransform(-17,-20.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(-17,-20.5,34,41), null);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leverageupto201();
	this.instance.setTransform(-78.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol15, new cjs.Rectangle(-78.5,-10,157,20), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Golongorshortinglobalmarkets();
	this.instance.setTransform(-176,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(-176,-12,352,24), null);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.AppleLogoblack();
	this.instance.setTransform(-10,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(-10,-12,20,24), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fblogo();
	this.instance.setTransform(-16,-16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(-16,-16,32,32), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.teslalogo();
	this.instance.setTransform(-10.5,-10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(-10.5,-10.5,21,21), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.googlelogo();
	this.instance.setTransform(-10,-10.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-10,-10.5,20,21), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Layer2();
	this.instance.setTransform(-22.5,-7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(-22.5,-7,45,14), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Microsoftlogoandwordmarkcopy();
	this.instance.setTransform(-10.5,-10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-10.5,-10,21,20), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.TradeAppleFacebookTeslaandmanymore();
	this.instance.setTransform(-221,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(-221,-11,442,22), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Trade10000stockCFDsonthebiggestexchanges();
	this.instance.setTransform(-135.5,-24.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-135.5,-24.5,271,49), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shutterstock_1434701594();
	this.instance.setTransform(-364,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-364,-45,728,90), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Layer1();
	this.instance.setTransform(-364,-45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-364,-45,728,90), null);


// stage content:
(lib.FPM_72860_HTML5Canvas = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Trade_10_000__stock_CFDs_on_the_biggest_exchanges
	this.instance = new lib.Symbol18();
	this.instance.setTransform(271,33.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(275).to({_off:false},0).to({alpha:1},19).wait(147));

	// t3b
	this.instance_1 = new lib.Symbol19();
	this.instance_1.setTransform(271,71);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(284).to({_off:false},0).to({alpha:1},12).to({alpha:0},8).to({alpha:1},7).to({alpha:0},8).to({alpha:1},8).to({alpha:0},9).to({alpha:1},10).to({alpha:0},10).to({alpha:1},10).wait(75));

	// Vector_Smart_Object_1
	this.instance_2 = new lib.Symbol22();
	this.instance_2.setTransform(449.5,32);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(297).to({_off:false},0).to({alpha:1},17).wait(127));

	// Vector_Smart_Object1
	this.instance_3 = new lib.Symbol17();
	this.instance_3.setTransform(541,31.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(304).to({_off:false},0).to({alpha:1},17).wait(120));

	// Vector_Smart_Object_2
	this.instance_4 = new lib.Symbol21();
	this.instance_4.setTransform(449.5,67);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(311).to({_off:false},0).to({alpha:1},17).wait(113));

	// Vector_Smart_Object
	this.instance_5 = new lib.Symbol20();
	this.instance_5.setTransform(540.5,69);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(318).to({_off:false},0).to({alpha:1},17).wait(106));

	// Leverage_up_to_20_1
	this.instance_6 = new lib.Symbol15();
	this.instance_6.setTransform(363.5,64);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(200).to({_off:false},0).to({alpha:1},16).wait(43).to({alpha:0},15).to({_off:true},1).wait(166));

	// Go_long_or_short_in_global_markets
	this.instance_7 = new lib.Symbol14();
	this.instance_7.setTransform(363,32);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(191).to({_off:false},0).to({alpha:1},16).wait(52).to({alpha:0},15).to({_off:true},1).wait(166));

	// Layer_2
	this.instance_8 = new lib.Symbol9();
	this.instance_8.setTransform(537.5,65);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(129).to({_off:false},0).to({alpha:1},12).wait(34).to({alpha:0},15).to({_off:true},1).wait(250));

	// Microsoft_logo_and_wordmark_copy
	this.instance_9 = new lib.Symbol8();
	this.instance_9.setTransform(456.5,63);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(122).to({_off:false},0).to({alpha:1},12).wait(41).to({alpha:0},15).to({_off:true},1).wait(250));

	// google_logo
	this.instance_10 = new lib.Symbol10();
	this.instance_10.setTransform(388,63.5);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(115).to({_off:false},0).to({alpha:1},12).wait(48).to({alpha:0},15).to({_off:true},1).wait(250));

	// tesla_logo
	this.instance_11 = new lib.Symbol11();
	this.instance_11.setTransform(320.5,63.5);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(108).to({_off:false},0).to({alpha:1},12).wait(55).to({alpha:0},15).to({_off:true},1).wait(250));

	// fb_logo
	this.instance_12 = new lib.Symbol12();
	this.instance_12.setTransform(246,63);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(101).to({_off:false},0).to({alpha:1},12).wait(62).to({alpha:0},15).to({_off:true},1).wait(250));

	// Apple_Logo_black
	this.instance_13 = new lib.Symbol13();
	this.instance_13.setTransform(172,63);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(94).to({_off:false},0).to({alpha:1},12).wait(69).to({alpha:0},15).to({_off:true},1).wait(250));

	// Trade_Apple__Facebook__Tesla_and_many_more_
	this.instance_14 = new lib.Symbol7();
	this.instance_14.setTransform(360,27);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(80).to({_off:false},0).to({alpha:1},13).wait(82).to({alpha:0},15).to({_off:true},1).wait(250));

	// Trade_10_000__stock_CFDs__on_the_biggest_exchanges
	this.instance_15 = new lib.Symbol6();
	this.instance_15.setTransform(357.5,45.5);
	this.instance_15.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({alpha:1},16).wait(46).to({alpha:0},17).to({_off:true},1).wait(361));

	// fpmarkets_logo_negative_stacked_RGB
	this.instance_16 = new lib.fpmarketslogonegativestackedRGB();
	this.instance_16.setTransform(14,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(441));

	// Rectangle_10_copy_4
	this.instance_17 = new lib.Rectangle10copy4();
	this.instance_17.setTransform(127,12);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(441));

	// trade_now
	this.instance_18 = new lib.Symbol23();
	this.instance_18.setTransform(658.5,31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(441));

	// Rounded_Rectangle_1
	this.instance_19 = new lib.Symbol24();
	this.instance_19.setTransform(658.5,31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(372).to({alpha:0},13).to({alpha:1},12).to({alpha:0},10).to({alpha:1},12).to({alpha:0},11).to({alpha:1},10).wait(1));

	// CFD_Trading_is_risky__Read_PDS__at_fpmarkets_com_AFSL286354
	this.instance_20 = new lib.CFDTradingisriskyReadPDSatfpmarketscomAFSL286354();
	this.instance_20.setTransform(596,59);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(441));

	// Layer_1
	this.instance_21 = new lib.Symbol4();
	this.instance_21.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(441));

	// shutterstock_1434701594
	this.instance_22 = new lib.Symbol5();
	this.instance_22.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(441));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,364,45);
// library properties:
lib.properties = {
	id: '75CE66A019504A7BB518B1B2B4D87292',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/FPM_728_60_HTML5 Canvas_atlas_.png", id:"FPM_728_60_HTML5 Canvas_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['75CE66A019504A7BB518B1B2B4D87292'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;